package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern TGP Enterprise Design Tokens
val TgpNavyDark = Color(0xFF0A0F1D)
val TgpNavySurface = Color(0xFF131C31)
val TgpNavyCard = Color(0xFF18233C)
val TgpNavyBorder = Color(0xFF263554)

val TgpPrimary = Color(0xFF2563EB)
val TgpPrimaryHover = Color(0xFF1D4ED8)
val TgpPrimaryLight = Color(0xFFEFF6FF)
val TgpPrimaryContainer = Color(0xFFDBEAFE)

val TgpSecondary = Color(0xFF0D9488)
val TgpSecondaryContainer = Color(0xFFCCFBF1)

val TgpAccentGold = Color(0xFFF59E0B)
val TgpAccentGoldLight = Color(0xFFFEF3C7)

val TgpSuccess = Color(0xFF10B981)
val TgpSuccessLight = Color(0xFFD1FAE5)

val TgpDanger = Color(0xFFEF4444)
val TgpDangerLight = Color(0xFFFEE2E2)

val TgpWarning = Color(0xFFF97316)
val TgpWarningLight = Color(0xFFFFEDD5)

val TgpPurple = Color(0xFF8B5CF6)
val TgpPurpleLight = Color(0xFFEDE9FE)

val TgpLightBackground = Color(0xFFF8FAFC)
val TgpLightSurface = Color(0xFFFFFFFF)
val TgpLightCard = Color(0xFFFFFFFF)
val TgpLightBorder = Color(0xFFE2E8F0)
val TgpTextPrimary = Color(0xFF0F172A)
val TgpTextSecondary = Color(0xFF475569)
val TgpTextMuted = Color(0xFF94A3B8)
