package com.example.tgp.data.repository

import androidx.room.withTransaction
import com.example.tgp.data.local.AppDatabase
import com.example.tgp.data.local.SecurityHelper
import com.example.tgp.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.*

data class UserSession(
    val user: UserEntity,
    val assignedBusinessIds: List<String> = emptyList(),
    val staffBinding: StaffBusinessBindingEntity? = null
)

data class FinancialSummary(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val balance: Double = 0.0,
    val netProfit: Double = 0.0,
    val transactionCount: Int = 0
)

data class CartItem(
    val item: ItemEntity,
    val quantity: Double
)

class TgpRepository(private val database: AppDatabase) {
    private val userDao = database.userDao()
    private val businessDao = database.businessDao()
    private val itemDao = database.itemDao()
    private val mutationDao = database.stockMutationDao()
    private val ledgerDao = database.ledgerDao()
    private val transferDao = database.transferDao()
    private val damagedDao = database.damagedGoodsDao()
    private val saleDao = database.saleDao()
    private val attendanceDao = database.attendanceDao()
    private val auditLogDao = database.auditLogDao()

    // -------------------------------------------------------------
    // SETUP & AUTHENTICATION
    // -------------------------------------------------------------

    suspend fun isMasterConfigured(): Boolean {
        return userDao.countMaster() > 0
    }

    suspend fun getMasterUser(): UserEntity? {
        return userDao.getMasterUser()
    }

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    suspend fun resetMasterAccount(): Result<Unit> {
        return database.withTransaction {
            val master = userDao.getMasterUser()
            if (master != null) {
                userDao.deleteUser(master.userId)
                auditLogDao.insertLog(
                    AuditLogEntity(
                        userId = "SYSTEM",
                        username = "system",
                        role = UserRole.MASTER,
                        action = "MASTER_RESET",
                        details = "Master account was reset from recovery menu."
                    )
                )
            }
            Result.success(Unit)
        }
    }

    suspend fun setupInitialMaster(username: String, password: String, fullName: String): Result<UserEntity> {
        if (username.isBlank() || password.length < 6 || fullName.isBlank()) {
            return Result.failure(IllegalArgumentException("Username, nama lengkap harus diisi, dan password minimal 6 karakter."))
        }

        return database.withTransaction {
            if (userDao.countMaster() > 0) {
                return@withTransaction Result.failure(IllegalStateException("MASTER kanonikal sudah terkonfigurasi. Tidak dapat membuat MASTER baru."))
            }

            val salt = SecurityHelper.generateSalt()
            val hash = SecurityHelper.hashPassword(password, salt)
            val masterUser = UserEntity(
                username = username.trim().lowercase(),
                passwordHash = hash,
                salt = salt,
                fullName = fullName.trim(),
                role = UserRole.MASTER,
                ownerId = null
            )
            userDao.insertUser(masterUser)

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = masterUser.userId,
                    username = masterUser.username,
                    role = masterUser.role,
                    action = "INITIAL_MASTER_CONFIGURED",
                    details = "Canonical platform MASTER account securely configured."
                )
            )

            Result.success(masterUser)
        }
    }

    suspend fun login(username: String, password: String): Result<UserSession> {
        val user = userDao.getUserByUsername(username.trim().lowercase())
            ?: return Result.failure(IllegalArgumentException("Username atau password salah."))

        val isValid = SecurityHelper.verifyPassword(password, user.salt, user.passwordHash)
        if (!isValid) {
            return Result.failure(IllegalArgumentException("Username atau password salah."))
        }

        val assignedBusinessIds = if (user.role == UserRole.ADMIN_OWNER) {
            userDao.getAssignedBusinessIds(user.userId)
        } else {
            emptyList()
        }

        val staffBinding = if (user.role in listOf(UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER)) {
            userDao.getStaffBinding(user.userId)
        } else {
            null
        }

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = user.userId,
                username = user.username,
                role = user.role,
                action = "USER_LOGIN",
                details = "User logged in with role ${user.role.name}."
            )
        )

        if (user.role == UserRole.OWNER) {
            ensureSampleBusinessesForOwner(user.userId)
        }

        return Result.success(
            UserSession(
                user = user,
                assignedBusinessIds = assignedBusinessIds,
                staffBinding = staffBinding
            )
        )
    }

    suspend fun quickLoginDemoOwner(): Result<UserSession> {
        return database.withTransaction {
            if (userDao.countMaster() == 0) {
                val masterSalt = SecurityHelper.generateSalt()
                val masterHash = SecurityHelper.hashPassword("master123", masterSalt)
                userDao.insertUser(
                    UserEntity(
                        username = "master",
                        passwordHash = masterHash,
                        salt = masterSalt,
                        fullName = "Master Administrator",
                        role = UserRole.MASTER
                    )
                )
            }

            var owner = userDao.getUserByUsername("owner")
            if (owner == null) {
                val salt = SecurityHelper.generateSalt()
                val hash = SecurityHelper.hashPassword("owner123", salt)
                owner = UserEntity(
                    username = "owner",
                    passwordHash = hash,
                    salt = salt,
                    fullName = "Budi Santoso",
                    role = UserRole.OWNER
                )
                userDao.insertUser(owner)
            }

            ensureSampleBusinessesForOwner(owner.userId)

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = owner.userId,
                    username = owner.username,
                    role = owner.role,
                    action = "DEMO_OWNER_LOGIN",
                    details = "Quick demo access for role OWNER with sample Business A, B, C."
                )
            )

            Result.success(
                UserSession(
                    user = owner,
                    assignedBusinessIds = emptyList(),
                    staffBinding = null
                )
            )
        }
    }

    suspend fun ensureSampleBusinessesForOwner(ownerId: String) {
        val existing = businessDao.getBusinessesByOwnerList(ownerId)
        val existingNames = existing.map { it.name }
        val now = System.currentTimeMillis()
        val day = 86400000L

        // 1. Business A: Retail & Fashion
        if (!existingNames.any { it.equals("Business A", ignoreCase = true) }) {
            val bizA = BusinessEntity(
                ownerId = ownerId,
                name = "Business A",
                templateType = BusinessTemplate.RETAIL,
                activeModules = "pos,inventory,transfer,approval,damaged_goods,finance,attendance,reports"
            )
            businessDao.insertBusiness(bizA)

            val itemsA = listOf(
                ItemEntity(businessId = bizA.businessId, name = "Kemeja Formal Oxford", sku = "BA-KEM-01", category = "Pakaian", type = "PRODUCT", costPrice = 110000.0, sellingPrice = 175000.0, stockQuantity = 45.0, unit = "pcs"),
                ItemEntity(businessId = bizA.businessId, name = "Celana Chino Slim", sku = "BA-CHN-02", category = "Pakaian", type = "PRODUCT", costPrice = 125000.0, sellingPrice = 195000.0, stockQuantity = 35.0, unit = "pcs"),
                ItemEntity(businessId = bizA.businessId, name = "Kaos Katun Combed 30s", sku = "BA-KAO-03", category = "Pakaian", type = "PRODUCT", costPrice = 45000.0, sellingPrice = 85000.0, stockQuantity = 70.0, unit = "pcs"),
                ItemEntity(businessId = bizA.businessId, name = "Jaket Bomber Urban", sku = "BA-JKT-04", category = "Pakaian", type = "PRODUCT", costPrice = 180000.0, sellingPrice = 290000.0, stockQuantity = 30.0, unit = "pcs")
            )
            itemsA.forEach { item ->
                itemDao.insertItem(item)
                mutationDao.insertMutation(
                    StockMutationEntity(
                        businessId = bizA.businessId,
                        itemId = item.itemId,
                        itemName = item.name,
                        changeQty = item.stockQuantity,
                        finalQty = item.stockQuantity,
                        type = MutationType.INITIAL,
                        referenceId = "INIT_${item.sku}",
                        note = "Stok Awal Bisnis A",
                        performedBy = "system"
                    )
                )
            }

            // Sales orders (for recent transactions)
            val salesA = listOf(
                SaleOrderEntity(receiptNumber = "INV-BA-041", businessId = bizA.businessId, cashierName = "Kasir A", totalAmount = 370000.0, paymentMethod = PaymentMethod.QRIS, itemsSummary = "Kemeja Formal Oxford (1x), Celana Chino Slim (1x)", timestamp = now - 2 * day),
                SaleOrderEntity(receiptNumber = "INV-BA-042", businessId = bizA.businessId, cashierName = "Kasir A", totalAmount = 550000.0, paymentMethod = PaymentMethod.TRANSFER, itemsSummary = "Jaket Bomber Urban (1x), Kaos Katun Combed 30s (1x)", timestamp = now - 5 * 3600000L)
            )
            salesA.forEach { saleDao.insertSale(it) }

            // Ledger records
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizA.businessId,
                    type = LedgerType.PEMASUKAN,
                    category = "PENJUALAN",
                    amount = 14850000.0,
                    referenceId = "REV_BA_TOTAL",
                    description = "Penjualan Retail Konsolidasi (42 Transaksi)",
                    timestamp = now - 1 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizA.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "SEWA_OUTLET",
                    amount = 3500000.0,
                    referenceId = "EXP_BA_01",
                    description = "Biaya Sewa Tempat & Outlet Toko",
                    timestamp = now - 5 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizA.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "OPERASIONAL",
                    amount = 1700000.0,
                    referenceId = "EXP_BA_02",
                    description = "Listrik, Perlengkapan Packaging & Kebersihan",
                    timestamp = now - 2 * day,
                    createdBy = "system"
                )
            )
        }

        // 2. Business B: Food & Beverage
        if (!existingNames.any { it.equals("Business B", ignoreCase = true) }) {
            val bizB = BusinessEntity(
                ownerId = ownerId,
                name = "Business B",
                templateType = BusinessTemplate.FNB,
                activeModules = "pos,inventory,transfer,approval,damaged_goods,finance,attendance,reports"
            )
            businessDao.insertBusiness(bizB)

            val itemsB = listOf(
                ItemEntity(businessId = bizB.businessId, name = "Espresso Single Origin", sku = "BB-ESP-01", category = "Minuman", type = "PRODUCT", costPrice = 10000.0, sellingPrice = 26000.0, stockQuantity = 120.0, unit = "cup"),
                ItemEntity(businessId = bizB.businessId, name = "Matcha Latte Oatmilk", sku = "BB-MTC-02", category = "Minuman", type = "PRODUCT", costPrice = 14000.0, sellingPrice = 34000.0, stockQuantity = 85.0, unit = "cup"),
                ItemEntity(businessId = bizB.businessId, name = "Croissant Butter Almond", sku = "BB-CRS-03", category = "Pastry", type = "PRODUCT", costPrice = 15000.0, sellingPrice = 32000.0, stockQuantity = 40.0, unit = "pcs"),
                ItemEntity(businessId = bizB.businessId, name = "Signature Beef Burger", sku = "BB-BGR-04", category = "Makanan", type = "PRODUCT", costPrice = 25000.0, sellingPrice = 52000.0, stockQuantity = 35.0, unit = "porsi")
            )
            itemsB.forEach { item ->
                itemDao.insertItem(item)
                mutationDao.insertMutation(
                    StockMutationEntity(
                        businessId = bizB.businessId,
                        itemId = item.itemId,
                        itemName = item.name,
                        changeQty = item.stockQuantity,
                        finalQty = item.stockQuantity,
                        type = MutationType.INITIAL,
                        referenceId = "INIT_${item.sku}",
                        note = "Stok Awal Bisnis B",
                        performedBy = "system"
                    )
                )
            }

            val salesB = listOf(
                SaleOrderEntity(receiptNumber = "INV-BB-097", businessId = bizB.businessId, cashierName = "Barista B", totalAmount = 144000.0, paymentMethod = PaymentMethod.QRIS, itemsSummary = "Signature Beef Burger (2x), Espresso (1x)", timestamp = now - 1 * day),
                SaleOrderEntity(receiptNumber = "INV-BB-098", businessId = bizB.businessId, cashierName = "Barista B", totalAmount = 92000.0, paymentMethod = PaymentMethod.CASH, itemsSummary = "Matcha Latte (1x), Croissant Butter (2x)", timestamp = now - 3 * 3600000L)
            )
            salesB.forEach { saleDao.insertSale(it) }

            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizB.businessId,
                    type = LedgerType.PEMASUKAN,
                    category = "PENJUALAN",
                    amount = 22400000.0,
                    referenceId = "REV_BB_TOTAL",
                    description = "Penjualan Cafe & Makanan (98 Transaksi)",
                    timestamp = now - 1 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizB.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "BAHAN_BAKU",
                    amount = 5800000.0,
                    referenceId = "EXP_BB_01",
                    description = "Pengadaan Biji Kopi, Susu Segar, Daging Sapi",
                    timestamp = now - 4 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizB.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "OPERASIONAL",
                    amount = 3100000.0,
                    referenceId = "EXP_BB_02",
                    description = "Gas Elpiji, Listrik Daya Tinggi & Mesin Espresso",
                    timestamp = now - 2 * day,
                    createdBy = "system"
                )
            )
        }

        // 3. Business C: Pharmacy & Healthcare Service
        if (!existingNames.any { it.equals("Business C", ignoreCase = true) }) {
            val bizC = BusinessEntity(
                ownerId = ownerId,
                name = "Business C",
                templateType = BusinessTemplate.SERVICE,
                activeModules = "pos,inventory,transfer,approval,damaged_goods,finance,attendance,reports"
            )
            businessDao.insertBusiness(bizC)

            val itemsC = listOf(
                ItemEntity(businessId = bizC.businessId, name = "Multivitamin Kompleks Plus", sku = "BC-VIT-01", category = "Vitamin", type = "PRODUCT", costPrice = 55000.0, sellingPrice = 95000.0, stockQuantity = 95.0, unit = "botol"),
                ItemEntity(businessId = bizC.businessId, name = "Masker Medis 3-Ply 50s", sku = "BC-MSK-02", category = "Alkes", type = "PRODUCT", costPrice = 18000.0, sellingPrice = 38000.0, stockQuantity = 140.0, unit = "box"),
                ItemEntity(businessId = bizC.businessId, name = "Termometer Digital Infrared", sku = "BC-THM-03", category = "Alkes", type = "PRODUCT", costPrice = 55000.0, sellingPrice = 110000.0, stockQuantity = 40.0, unit = "unit"),
                ItemEntity(businessId = bizC.businessId, name = "Suplemen Imunitas C & D3", sku = "BC-SUP-04", category = "Vitamin", type = "PRODUCT", costPrice = 75000.0, sellingPrice = 135000.0, stockQuantity = 70.0, unit = "botol")
            )
            itemsC.forEach { item ->
                itemDao.insertItem(item)
                mutationDao.insertMutation(
                    StockMutationEntity(
                        businessId = bizC.businessId,
                        itemId = item.itemId,
                        itemName = item.name,
                        changeQty = item.stockQuantity,
                        finalQty = item.stockQuantity,
                        type = MutationType.INITIAL,
                        referenceId = "INIT_${item.sku}",
                        note = "Stok Awal Bisnis C",
                        performedBy = "system"
                    )
                )
            }

            val salesC = listOf(
                SaleOrderEntity(receiptNumber = "INV-BC-063", businessId = bizC.businessId, cashierName = "Apoteker C", totalAmount = 230000.0, paymentMethod = PaymentMethod.QRIS, itemsSummary = "Multivitamin Kompleks (1x), Suplemen Imunitas (1x)", timestamp = now - 2 * day),
                SaleOrderEntity(receiptNumber = "INV-BC-064", businessId = bizC.businessId, cashierName = "Apoteker C", totalAmount = 148000.0, paymentMethod = PaymentMethod.CASH, itemsSummary = "Masker Medis 3-Ply (1x), Termometer Digital (1x)", timestamp = now - 6 * 3600000L)
            )
            salesC.forEach { saleDao.insertSale(it) }

            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizC.businessId,
                    type = LedgerType.PEMASUKAN,
                    category = "PENJUALAN",
                    amount = 18250000.0,
                    referenceId = "REV_BC_TOTAL",
                    description = "Penjualan Farmasi & Alkes (64 Transaksi)",
                    timestamp = now - 1 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizC.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "PENGADAAN_OBAT",
                    amount = 4800000.0,
                    referenceId = "EXP_BC_01",
                    description = "Pengadaan Obat & Lisensi BPOM",
                    timestamp = now - 4 * day,
                    createdBy = "system"
                )
            )
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = bizC.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "OPERASIONAL",
                    amount = 2300000.0,
                    referenceId = "EXP_BC_02",
                    description = "Suhu Terkontrol, Sterilisasi & Kebersihan",
                    timestamp = now - 2 * day,
                    createdBy = "system"
                )
            )
        }
    }

    fun getSalesForBusinesses(businessIds: List<String>): Flow<List<SaleOrderEntity>> =
        if (businessIds.isEmpty()) kotlinx.coroutines.flow.flowOf(emptyList())
        else saleDao.getSalesForMultipleBusinesses(businessIds)

    fun getItemsForBusinesses(businessIds: List<String>): Flow<List<ItemEntity>> =
        if (businessIds.isEmpty()) kotlinx.coroutines.flow.flowOf(emptyList())
        else itemDao.getItemsForMultipleBusinesses(businessIds)

    // -------------------------------------------------------------
    // USER MANAGEMENT
    // -------------------------------------------------------------

    fun getAllOwners(): Flow<List<UserEntity>> = userDao.getAllOwners()

    fun getAdminOwners(ownerId: String): Flow<List<UserEntity>> = userDao.getAdminOwnersByOwner(ownerId)

    fun getStaffForBusiness(businessId: String): Flow<List<StaffBusinessBindingEntity>> =
        userDao.getStaffBindingsForBusiness(businessId)

    suspend fun createOwner(
        caller: UserEntity,
        username: String,
        password: String,
        fullName: String
    ): Result<UserEntity> {
        if (caller.role != UserRole.MASTER) {
            return Result.failure(SecurityException("Hanya MASTER yang dapat membuat akun OWNER."))
        }
        if (username.isBlank() || password.length < 6 || fullName.isBlank()) {
            return Result.failure(IllegalArgumentException("Data tidak valid. Password minimal 6 karakter."))
        }

        val existing = userDao.getUserByUsername(username.trim().lowercase())
        if (existing != null) {
            return Result.failure(IllegalArgumentException("Username sudah digunakan."))
        }

        val salt = SecurityHelper.generateSalt()
        val hash = SecurityHelper.hashPassword(password, salt)
        val ownerUser = UserEntity(
            username = username.trim().lowercase(),
            passwordHash = hash,
            salt = salt,
            fullName = fullName.trim(),
            role = UserRole.OWNER,
            ownerId = null
        )

        userDao.insertUser(ownerUser)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                action = "CREATE_OWNER",
                details = "MASTER created OWNER account: ${ownerUser.username} (${ownerUser.fullName})"
            )
        )

        return Result.success(ownerUser)
    }

    suspend fun createAdminOwner(
        caller: UserEntity,
        username: String,
        password: String,
        fullName: String,
        assignedBusinessIds: List<String>
    ): Result<UserEntity> {
        if (caller.role != UserRole.OWNER) {
            return Result.failure(SecurityException("Hanya OWNER yang dapat membuat ADMIN OWNER."))
        }
        if (username.isBlank() || password.length < 6 || fullName.isBlank()) {
            return Result.failure(IllegalArgumentException("Data tidak valid. Password minimal 6 karakter."))
        }

        val existing = userDao.getUserByUsername(username.trim().lowercase())
        if (existing != null) {
            return Result.failure(IllegalArgumentException("Username sudah digunakan."))
        }

        return database.withTransaction {
            val salt = SecurityHelper.generateSalt()
            val hash = SecurityHelper.hashPassword(password, salt)
            val adminUser = UserEntity(
                username = username.trim().lowercase(),
                passwordHash = hash,
                salt = salt,
                fullName = fullName.trim(),
                role = UserRole.ADMIN_OWNER,
                ownerId = caller.userId // Bound to this owner
            )
            userDao.insertUser(adminUser)

            // Validate that assigned businesses actually belong to caller OWNER
            val ownerBusinesses = businessDao.getBusinessesByOwnerList(caller.userId).map { it.businessId }
            for (bId in assignedBusinessIds) {
                if (ownerBusinesses.contains(bId)) {
                    userDao.insertAdminAssignment(
                        AdminBusinessAssignmentEntity(
                            userId = adminUser.userId,
                            businessId = bId
                        )
                    )
                }
            }

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = caller.userId,
                    username = caller.username,
                    role = caller.role,
                    action = "CREATE_ADMIN_OWNER",
                    details = "OWNER created ADMIN OWNER: ${adminUser.username}, assigned ${assignedBusinessIds.size} businesses."
                )
            )

            Result.success(adminUser)
        }
    }

    suspend fun createStaffUser(
        caller: UserEntity,
        businessId: String,
        username: String,
        password: String,
        fullName: String,
        role: UserRole
    ): Result<UserEntity> {
        if (role !in listOf(UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER)) {
            return Result.failure(IllegalArgumentException("Role staff harus LEADER, STAFF, atau CASHIER."))
        }

        // Authorization validation:
        val business = businessDao.getBusinessById(businessId)
            ?: return Result.failure(IllegalArgumentException("Business tidak ditemukan."))

        val isAuthorized = when (caller.role) {
            UserRole.OWNER -> business.ownerId == caller.userId
            UserRole.ADMIN_OWNER -> {
                val assigned = userDao.getAssignedBusinessIds(caller.userId)
                assigned.contains(businessId) && business.ownerId == caller.ownerId
            }
            UserRole.LEADER -> {
                val binding = userDao.getStaffBinding(caller.userId)
                binding?.businessId == businessId && role in listOf(UserRole.STAFF, UserRole.CASHIER)
            }
            else -> false
        }

        if (!isAuthorized) {
            return Result.failure(SecurityException("Anda tidak memiliki otorisasi untuk menambah staff pada Business ini."))
        }

        val existing = userDao.getUserByUsername(username.trim().lowercase())
        if (existing != null) {
            return Result.failure(IllegalArgumentException("Username sudah digunakan."))
        }

        return database.withTransaction {
            val salt = SecurityHelper.generateSalt()
            val hash = SecurityHelper.hashPassword(password, salt)
            val staffUser = UserEntity(
                username = username.trim().lowercase(),
                passwordHash = hash,
                salt = salt,
                fullName = fullName.trim(),
                role = role,
                ownerId = business.ownerId
            )
            userDao.insertUser(staffUser)

            userDao.insertStaffBinding(
                StaffBusinessBindingEntity(
                    userId = staffUser.userId,
                    businessId = businessId,
                    role = role
                )
            )

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = caller.userId,
                    username = caller.username,
                    role = caller.role,
                    businessId = businessId,
                    action = "CREATE_STAFF",
                    details = "Created ${role.name} (${staffUser.username}) for business ${business.name}."
                )
            )

            Result.success(staffUser)
        }
    }

    // -------------------------------------------------------------
    // BUSINESS MANAGEMENT (Strict max 2 modules, strict owner isolation)
    // -------------------------------------------------------------

    fun getBusinessesForUser(session: UserSession): Flow<List<BusinessEntity>> {
        return when (session.user.role) {
            UserRole.MASTER -> businessDao.getAllBusinesses()
            UserRole.OWNER -> businessDao.getBusinessesByOwner(session.user.userId)
            UserRole.ADMIN_OWNER -> businessDao.getBusinessesByIds(session.assignedBusinessIds)
            UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER -> {
                val bId = session.staffBinding?.businessId
                if (bId != null) businessDao.getBusinessesByIds(listOf(bId)) else businessDao.getBusinessesByIds(emptyList())
            }
        }
    }

    suspend fun getBusinessById(businessId: String): BusinessEntity? {
        return businessDao.getBusinessById(businessId)
    }

    suspend fun createBusiness(
        caller: UserEntity,
        name: String,
        template: BusinessTemplate,
        modules: List<BusinessModule>
    ): Result<BusinessEntity> {
        if (caller.role != UserRole.OWNER) {
            return Result.failure(SecurityException("Hanya OWNER yang dapat membuat Business."))
        }
        if (name.isBlank()) {
            return Result.failure(IllegalArgumentException("Nama Business wajib diisi."))
        }
        if (modules.isEmpty()) {
            return Result.failure(IllegalArgumentException("Pilih minimal 1 modul untuk Business."))
        }

        val business = BusinessEntity(
            ownerId = caller.userId,
            name = name.trim(),
            templateType = template,
            activeModules = modules.joinToString(",") { it.id }
        )

        businessDao.insertBusiness(business)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = business.businessId,
                action = "CREATE_BUSINESS",
                details = "Created Business: ${business.name} [Template: ${template.name}, Modules: ${business.activeModules}]"
            )
        )

        return Result.success(business)
    }

    // -------------------------------------------------------------
    // ITEMS & INVENTORY
    // -------------------------------------------------------------

    fun getItemsForBusiness(businessId: String): Flow<List<ItemEntity>> {
        return itemDao.getItemsByBusiness(businessId)
    }

    suspend fun createOrUpdateItem(caller: UserEntity, item: ItemEntity): Result<Unit> {
        if (caller.role == UserRole.CASHIER) {
            return Result.failure(SecurityException("CASHIER tidak diizinkan mengubah katalog item."))
        }
        itemDao.insertItem(item)
        mutationDao.insertMutation(
            StockMutationEntity(
                businessId = item.businessId,
                itemId = item.itemId,
                itemName = item.name,
                changeQty = item.stockQuantity,
                finalQty = item.stockQuantity,
                type = MutationType.INITIAL,
                referenceId = "ITEM_INIT_${item.itemId.take(8)}",
                note = "Penyesuaian item awal",
                performedBy = caller.username
            )
        )
        return Result.success(Unit)
    }

    // -------------------------------------------------------------
    // POS (Cash / Transfer / QRIS) - Atomic deduction & Ledger entry
    // -------------------------------------------------------------

    suspend fun checkoutPos(
        caller: UserEntity,
        businessId: String,
        cart: List<CartItem>,
        paymentMethod: PaymentMethod
    ): Result<SaleOrderEntity> {
        if (cart.isEmpty()) {
            return Result.failure(IllegalArgumentException("Keranjang belanja kosong."))
        }

        return database.withTransaction {
            var totalAmount = 0.0
            val itemsSummaryList = mutableListOf<String>()

            // 1. Check stock availability for all items
            for (cartItem in cart) {
                val dbItem = itemDao.getItemById(cartItem.item.itemId)
                    ?: return@withTransaction Result.failure(IllegalArgumentException("Item '${cartItem.item.name}' tidak ditemukan."))

                if (dbItem.type != "SERVICE" && dbItem.stockQuantity < cartItem.quantity) {
                    return@withTransaction Result.failure(
                        IllegalStateException("Stok tidak mencukupi untuk '${dbItem.name}'. Tersedia: ${dbItem.stockQuantity}, Dibutuhkan: ${cartItem.quantity}")
                    )
                }

                val subtotal = cartItem.quantity * dbItem.sellingPrice
                totalAmount += subtotal
                itemsSummaryList.add("${dbItem.name} (${cartItem.quantity}x)")
            }

            val receiptNo = "POS-${SimpleDateFormat("yyMMddHHmmss", Locale.getDefault()).format(Date())}-${Random().nextInt(900) + 100}"
            val timestamp = System.currentTimeMillis()

            // 2. Deduct stock safely & record mutations
            for (cartItem in cart) {
                if (cartItem.item.type != "SERVICE") {
                    val updatedRows = itemDao.deductStockSafely(cartItem.item.itemId, cartItem.quantity, timestamp)
                    if (updatedRows == 0) {
                        return@withTransaction Result.failure(
                            IllegalStateException("Gagal memotong stok '${cartItem.item.name}'. Stok mungkin berubah saat proses.")
                        )
                    }

                    val currentItem = itemDao.getItemById(cartItem.item.itemId)!!
                    mutationDao.insertMutation(
                        StockMutationEntity(
                            businessId = businessId,
                            itemId = cartItem.item.itemId,
                            itemName = cartItem.item.name,
                            changeQty = -cartItem.quantity,
                            finalQty = currentItem.stockQuantity,
                            type = MutationType.POS_SALE,
                            referenceId = receiptNo,
                            note = "Penjualan Kasir $receiptNo",
                            performedBy = caller.username,
                            timestamp = timestamp
                        )
                    )
                }
            }

            // 3. Insert Sale Order
            val saleOrder = SaleOrderEntity(
                receiptNumber = receiptNo,
                businessId = businessId,
                cashierName = caller.fullName,
                totalAmount = totalAmount,
                paymentMethod = paymentMethod,
                itemsSummary = itemsSummaryList.joinToString(", "),
                timestamp = timestamp
            )
            saleDao.insertSale(saleOrder)

            // 4. Record Ledger Entry (PEMASUKAN)
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = businessId,
                    type = LedgerType.PEMASUKAN,
                    category = "PENJUALAN_POS",
                    amount = totalAmount,
                    referenceId = receiptNo,
                    description = "Penjualan POS via ${paymentMethod.name} ($receiptNo)",
                    createdBy = caller.username,
                    timestamp = timestamp
                )
            )

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = caller.userId,
                    username = caller.username,
                    role = caller.role,
                    businessId = businessId,
                    action = "POS_SALE",
                    details = "Processed POS Sale: $receiptNo, Total: Rp $totalAmount via ${paymentMethod.name}"
                )
            )

            Result.success(saleOrder)
        }
    }

    // -------------------------------------------------------------
    // TRANSFER BARANG (Atomic, Same Owner Only, Draft -> Approve/Reject)
    // -------------------------------------------------------------

    fun getTransfersForOwner(ownerId: String): Flow<List<TransferEntity>> =
        transferDao.getTransfersByOwner(ownerId)

    fun getTransfersForBusiness(businessId: String): Flow<List<TransferEntity>> =
        transferDao.getTransfersByBusiness(businessId)

    fun getPendingTransfersForOwner(ownerId: String): Flow<List<TransferEntity>> =
        transferDao.getPendingTransfersByOwner(ownerId)

    suspend fun createTransferRequest(
        caller: UserEntity,
        sourceBusinessId: String,
        destBusinessId: String,
        itemId: String,
        quantity: Double,
        notes: String
    ): Result<TransferEntity> {
        if (sourceBusinessId == destBusinessId) {
            return Result.failure(IllegalArgumentException("Bisnis sumber dan tujuan transfer tidak boleh sama."))
        }
        if (quantity <= 0) {
            return Result.failure(IllegalArgumentException("Jumlah transfer harus lebih besar dari 0."))
        }

        val sourceBusiness = businessDao.getBusinessById(sourceBusinessId)
            ?: return Result.failure(IllegalArgumentException("Bisnis asal tidak ditemukan."))
        val destBusiness = businessDao.getBusinessById(destBusinessId)
            ?: return Result.failure(IllegalArgumentException("Bisnis tujuan tidak ditemukan."))

        // 1. MANDATORY RULE: Transfer hanya boleh antar Business yang dimiliki OWNER yang sama
        if (sourceBusiness.ownerId != destBusiness.ownerId) {
            return Result.failure(SecurityException("Ditolak: Transfer hanya diizinkan antar Business dalam satu OWNER yang sama."))
        }

        val sourceItem = itemDao.getItemById(itemId)
            ?: return Result.failure(IllegalArgumentException("Item sumber tidak ditemukan."))

        if (sourceItem.businessId != sourceBusinessId) {
            return Result.failure(IllegalArgumentException("Item tidak terdaftar pada bisnis asal."))
        }

        if (sourceItem.stockQuantity < quantity) {
            return Result.failure(IllegalStateException("Stok sumber tidak mencukupi (Tersedia: ${sourceItem.stockQuantity})."))
        }

        val ref = "TRF-${SimpleDateFormat("yyMMddHHmmss", Locale.getDefault()).format(Date())}-${Random().nextInt(900) + 100}"
        val unitValue = sourceItem.costPrice.takeIf { it > 0 } ?: sourceItem.sellingPrice
        val totalValue = unitValue * quantity

        val transfer = TransferEntity(
            transferReference = ref,
            sourceBusinessId = sourceBusinessId,
            sourceBusinessName = sourceBusiness.name,
            sourceLocation = sourceItem.location,
            destBusinessId = destBusinessId,
            destBusinessName = destBusiness.name,
            destLocation = "Outlet/Gudang Cabang",
            itemId = itemId,
            itemName = sourceItem.name,
            quantity = quantity,
            unitValue = unitValue,
            totalValue = totalValue,
            ownerId = sourceBusiness.ownerId,
            status = TransferStatus.PENDING,
            requestedBy = caller.fullName,
            notes = notes
        )

        // When created: STOK TIDAK BERUBAH DAN LEDGER TIDAK BERUBAH.
        transferDao.insertTransfer(transfer)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = sourceBusinessId,
                action = "TRANSFER_REQUESTED",
                details = "Requested Transfer $ref: ${sourceItem.name} ($quantity ${sourceItem.unit}) from ${sourceBusiness.name} to ${destBusiness.name}."
            )
        )

        return Result.success(transfer)
    }

    suspend fun rejectTransfer(caller: UserEntity, transferId: String, reason: String): Result<Unit> {
        val transfer = transferDao.getTransferById(transferId)
            ?: return Result.failure(IllegalArgumentException("Transfer tidak ditemukan."))

        if (transfer.status != TransferStatus.PENDING) {
            return Result.failure(IllegalStateException("Transfer sudah diproses sebelumnya (${transfer.status.name})."))
        }

        val updated = transfer.copy(
            status = TransferStatus.REJECTED,
            approvedBy = caller.fullName,
            processedAt = System.currentTimeMillis(),
            notes = if (reason.isNotBlank()) "${transfer.notes} [Ditolak: $reason]" else transfer.notes
        )

        // When REJECTED: STOK DAN LEDGER TIDAK BERUBAH, TETAPI HISTORI TETAP TERSIMPAN.
        transferDao.updateTransfer(updated)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = transfer.sourceBusinessId,
                action = "TRANSFER_REJECTED",
                details = "Transfer ${transfer.transferReference} REJECTED by ${caller.fullName}. Reason: $reason"
            )
        )

        return Result.success(Unit)
    }

    suspend fun approveTransfer(caller: UserEntity, transferId: String): Result<Unit> {
        return database.withTransaction {
            val transfer = transferDao.getTransferById(transferId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Transfer tidak ditemukan."))

            // Prevent double approval, duplicate processing, race condition
            if (transfer.status != TransferStatus.PENDING) {
                return@withTransaction Result.failure(IllegalStateException("Transfer sudah diproses sebelumnya (${transfer.status.name})."))
            }

            // 1. Validasi ownership Business
            val sourceBusiness = businessDao.getBusinessById(transfer.sourceBusinessId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Bisnis sumber tidak valid."))
            val destBusiness = businessDao.getBusinessById(transfer.destBusinessId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Bisnis tujuan tidak valid."))

            if (sourceBusiness.ownerId != destBusiness.ownerId || sourceBusiness.ownerId != transfer.ownerId) {
                return@withTransaction Result.failure(SecurityException("Pelanggaran Keamanan: Transfer antar OWNER berbeda dilarang."))
            }

            // 2. Validasi stok sumber (no negative stock)
            val sourceItem = itemDao.getItemById(transfer.itemId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Item sumber tidak ditemukan di database."))

            if (sourceItem.stockQuantity < transfer.quantity) {
                return@withTransaction Result.failure(
                    IllegalStateException("Stok sumber tidak mencukupi. Tersedia: ${sourceItem.stockQuantity}, Dibutuhkan: ${transfer.quantity}")
                )
            }

            val timestamp = System.currentTimeMillis()

            // 3. Kurangi stok sumber secara atomic
            val deducted = itemDao.deductStockSafely(sourceItem.itemId, transfer.quantity, timestamp)
            if (deducted == 0) {
                return@withTransaction Result.failure(IllegalStateException("Gagal memotong stok sumber (kemungkinan terjadi race condition)."))
            }
            val updatedSourceItem = itemDao.getItemById(sourceItem.itemId)!!

            // 4. Catat stock movement sumber
            mutationDao.insertMutation(
                StockMutationEntity(
                    businessId = sourceBusiness.businessId,
                    itemId = sourceItem.itemId,
                    itemName = sourceItem.name,
                    changeQty = -transfer.quantity,
                    finalQty = updatedSourceItem.stockQuantity,
                    type = MutationType.TRANSFER_OUT,
                    referenceId = transfer.transferReference,
                    note = "Transfer keluar ke ${destBusiness.name} (${transfer.transferReference})",
                    performedBy = caller.username,
                    timestamp = timestamp
                )
            )

            // 5. Tambahkan stok tujuan
            // Find existing matching item or create one in destination business
            var destItem = itemDao.findMatchingItem(destBusiness.businessId, sourceItem.sku, sourceItem.name)
            if (destItem == null) {
                destItem = ItemEntity(
                    businessId = destBusiness.businessId,
                    name = sourceItem.name,
                    sku = sourceItem.sku,
                    category = sourceItem.category,
                    type = sourceItem.type,
                    costPrice = sourceItem.costPrice,
                    sellingPrice = sourceItem.sellingPrice,
                    stockQuantity = transfer.quantity,
                    unit = sourceItem.unit,
                    location = transfer.destLocation,
                    recipeBom = sourceItem.recipeBom,
                    updatedAt = timestamp
                )
                itemDao.insertItem(destItem)
            } else {
                itemDao.addStock(destItem.itemId, transfer.quantity, timestamp)
                destItem = itemDao.getItemById(destItem.itemId)!!
            }

            // 6. Catat stock movement tujuan
            mutationDao.insertMutation(
                StockMutationEntity(
                    businessId = destBusiness.businessId,
                    itemId = destItem.itemId,
                    itemName = destItem.name,
                    changeQty = transfer.quantity,
                    finalQty = destItem.stockQuantity,
                    type = MutationType.TRANSFER_IN,
                    referenceId = transfer.transferReference,
                    note = "Transfer masuk dari ${sourceBusiness.name} (${transfer.transferReference})",
                    performedBy = caller.username,
                    timestamp = timestamp
                )
            )

            // 7. Catat ledger sumber sebagai PEMASUKAN
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = sourceBusiness.businessId,
                    type = LedgerType.PEMASUKAN,
                    category = "TRANSFER_KELUAR",
                    amount = transfer.totalValue,
                    referenceId = transfer.transferReference,
                    description = "Nilai transfer persediaan ke ${destBusiness.name} (${transfer.transferReference})",
                    createdBy = caller.username,
                    timestamp = timestamp
                )
            )

            // 8. Catat ledger tujuan sebagai PENGELUARAN
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = destBusiness.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "TRANSFER_MASUK",
                    amount = transfer.totalValue,
                    referenceId = transfer.transferReference,
                    description = "Akuisisi persediaan transfer dari ${sourceBusiness.name} (${transfer.transferReference})",
                    createdBy = caller.username,
                    timestamp = timestamp
                )
            )

            // 9. Simpan histori transfer & 10. Gunakan transfer_reference yang sama
            val approvedTransfer = transfer.copy(
                status = TransferStatus.APPROVED,
                approvedBy = caller.fullName,
                processedAt = timestamp
            )
            transferDao.updateTransfer(approvedTransfer)

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = caller.userId,
                    username = caller.username,
                    role = caller.role,
                    businessId = sourceBusiness.businessId,
                    action = "TRANSFER_APPROVED",
                    details = "ATOMIC TRANSFER APPROVED: ${transfer.transferReference}. Qty: ${transfer.quantity}, Total: Rp ${transfer.totalValue}"
                )
            )

            Result.success(Unit)
        }
    }

    // -------------------------------------------------------------
    // LAPORAN BARANG RUSAK (Damaged Goods Report)
    // -------------------------------------------------------------

    fun getDamagedGoodsForBusiness(businessId: String): Flow<List<DamagedGoodsReportEntity>> =
        damagedDao.getReportsByBusiness(businessId)

    fun getPendingDamagedGoodsForOwner(ownerId: String): Flow<List<DamagedGoodsReportEntity>> =
        damagedDao.getPendingReportsByOwner(ownerId)

    suspend fun createDamagedGoodsReport(
        caller: UserEntity,
        businessId: String,
        location: String,
        itemId: String,
        quantity: Double,
        reason: String
    ): Result<DamagedGoodsReportEntity> {
        if (quantity <= 0) {
            return Result.failure(IllegalArgumentException("Jumlah barang rusak harus > 0."))
        }
        if (reason.isBlank()) {
            return Result.failure(IllegalArgumentException("Alasan kerusakan harus dijelaskan."))
        }

        val item = itemDao.getItemById(itemId)
            ?: return Result.failure(IllegalArgumentException("Item tidak ditemukan."))

        val lossValue = (item.costPrice.takeIf { it > 0 } ?: item.sellingPrice) * quantity

        val report = DamagedGoodsReportEntity(
            businessId = businessId,
            location = location.ifBlank { item.location },
            itemId = itemId,
            itemName = item.name,
            quantity = quantity,
            lossValue = lossValue,
            reason = reason.trim(),
            reportedBy = caller.fullName,
            status = DamagedStatus.PENDING
        )

        damagedDao.insertReport(report)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = businessId,
                action = "DAMAGED_GOODS_REPORTED",
                details = "Reported damaged: ${item.name} ($quantity ${item.unit}), Reason: $reason"
            )
        )

        return Result.success(report)
    }

    suspend fun approveDamagedGoodsReport(caller: UserEntity, reportId: String): Result<Unit> {
        return database.withTransaction {
            val report = damagedDao.getReportById(reportId)
                ?: return@withTransaction Result.failure(IllegalArgumentException("Laporan tidak ditemukan."))

            if (report.status != DamagedStatus.PENDING) {
                return@withTransaction Result.failure(IllegalStateException("Laporan sudah diproses (${report.status.name})."))
            }

            val timestamp = System.currentTimeMillis()

            // Deduct stock atomically
            val deducted = itemDao.deductStockSafely(report.itemId, report.quantity, timestamp)
            if (deducted == 0) {
                return@withTransaction Result.failure(IllegalStateException("Stok tidak mencukupi untuk pemotongan barang rusak."))
            }

            val currentItem = itemDao.getItemById(report.itemId)!!

            // Record mutation
            mutationDao.insertMutation(
                StockMutationEntity(
                    businessId = report.businessId,
                    itemId = report.itemId,
                    itemName = report.itemName,
                    changeQty = -report.quantity,
                    finalQty = currentItem.stockQuantity,
                    type = MutationType.DAMAGED_GOODS,
                    referenceId = "DMG-${report.reportId.take(8)}",
                    note = "Barang Rusak: ${report.reason}",
                    performedBy = caller.username,
                    timestamp = timestamp
                )
            )

            // Record ledger entry as PENGELUARAN (kerugian/penghapusan)
            ledgerDao.insertLedger(
                LedgerTransactionEntity(
                    businessId = report.businessId,
                    type = LedgerType.PENGELUARAN,
                    category = "PENGHAPUSAN_RUSAK",
                    amount = report.lossValue,
                    referenceId = "DMG-${report.reportId.take(8)}",
                    description = "Kerugian Barang Rusak: ${report.itemName} (${report.reason})",
                    createdBy = caller.username,
                    timestamp = timestamp
                )
            )

            val updated = report.copy(
                status = DamagedStatus.APPROVED,
                approvedBy = caller.fullName,
                processedAt = timestamp
            )
            damagedDao.updateReport(updated)

            auditLogDao.insertLog(
                AuditLogEntity(
                    userId = caller.userId,
                    username = caller.username,
                    role = caller.role,
                    businessId = report.businessId,
                    action = "DAMAGED_GOODS_APPROVED",
                    details = "Approved damaged stock write-off: ${report.itemName} (${report.quantity}) by ${caller.fullName}"
                )
            )

            Result.success(Unit)
        }
    }

    suspend fun rejectDamagedGoodsReport(caller: UserEntity, reportId: String): Result<Unit> {
        val report = damagedDao.getReportById(reportId)
            ?: return Result.failure(IllegalArgumentException("Laporan tidak ditemukan."))

        if (report.status != DamagedStatus.PENDING) {
            return Result.failure(IllegalStateException("Laporan sudah diproses."))
        }

        val updated = report.copy(
            status = DamagedStatus.REJECTED,
            approvedBy = caller.fullName,
            processedAt = System.currentTimeMillis()
        )
        damagedDao.updateReport(updated)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = report.businessId,
                action = "DAMAGED_GOODS_REJECTED",
                details = "Rejected damaged stock write-off: ${report.itemName} by ${caller.fullName}"
            )
        )

        return Result.success(Unit)
    }

    // -------------------------------------------------------------
    // FINANCE & LEDGERS (Per-business isolated ledgers)
    // -------------------------------------------------------------

    fun getLedgerForBusiness(businessId: String): Flow<List<LedgerTransactionEntity>> =
        ledgerDao.getLedgerByBusiness(businessId)

    fun getLedgerForMultipleBusinesses(businessIds: List<String>): Flow<List<LedgerTransactionEntity>> =
        ledgerDao.getLedgerForMultipleBusinesses(businessIds)

    suspend fun addManualLedgerEntry(
        caller: UserEntity,
        businessId: String,
        type: LedgerType,
        category: String,
        amount: Double,
        description: String
    ): Result<Unit> {
        if (amount <= 0) {
            return Result.failure(IllegalArgumentException("Nominal transaksi harus > 0."))
        }
        if (description.isBlank()) {
            return Result.failure(IllegalArgumentException("Keterangan wajib diisi."))
        }

        val tx = LedgerTransactionEntity(
            businessId = businessId,
            type = type,
            category = category,
            amount = amount,
            referenceId = "MANUAL-${System.currentTimeMillis()}",
            description = description.trim(),
            createdBy = caller.username
        )
        ledgerDao.insertLedger(tx)

        auditLogDao.insertLog(
            AuditLogEntity(
                userId = caller.userId,
                username = caller.username,
                role = caller.role,
                businessId = businessId,
                action = "LEDGER_ENTRY",
                details = "Manual ${type.name}: Rp $amount ($description)"
            )
        )

        return Result.success(Unit)
    }

    // -------------------------------------------------------------
    // ATTENDANCE & AUDIT LOGS
    // -------------------------------------------------------------

    fun getAttendanceForBusiness(businessId: String): Flow<List<AttendanceEntity>> =
        attendanceDao.getAttendanceByBusiness(businessId)

    suspend fun recordAttendance(
        caller: UserEntity,
        businessId: String,
        type: String,
        note: String
    ): Result<Unit> {
        val att = AttendanceEntity(
            businessId = businessId,
            userId = caller.userId,
            userName = caller.fullName,
            type = type,
            note = note.trim()
        )
        attendanceDao.insertAttendance(att)
        return Result.success(Unit)
    }

    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = auditLogDao.getAllLogs()

    fun getAuditLogsForBusiness(businessId: String): Flow<List<AuditLogEntity>> =
        auditLogDao.getLogsByBusiness(businessId)
}
