package com.example.tgp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.tgp.data.model.*
import com.example.tgp.ui.components.RoleBadge
import com.example.tgp.ui.viewmodel.TgpViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateBusinessDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, template: BusinessTemplate, modules: List<BusinessModule>) -> Unit
) {
    var businessName by remember { mutableStateOf("") }
    var selectedTemplate by remember { mutableStateOf(BusinessTemplate.RETAIL) }
    var selectedModules by remember { mutableStateOf(setOf(BusinessModule.POS, BusinessModule.INVENTORY)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Tambah Business Baru", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Konfigurasi template & pilih modul yang diinginkan (bebas pilih semua)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = businessName,
                    onValueChange = { businessName = it },
                    label = { Text("Nama Business") },
                    placeholder = { Text("Contoh: Kopi Nusantara / Toko Maju") },
                    leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_business_name")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Pilih Template Bisnis:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                BusinessTemplate.values().forEach { template ->
                    val isSelected = selectedTemplate == template
                    Surface(
                        onClick = {
                            selectedTemplate = template
                            selectedModules = when (template) {
                                BusinessTemplate.RETAIL -> setOf(BusinessModule.POS, BusinessModule.INVENTORY, BusinessModule.FINANCE)
                                BusinessTemplate.SERVICE -> setOf(BusinessModule.POS, BusinessModule.ATTENDANCE, BusinessModule.FINANCE)
                                BusinessTemplate.FNB -> setOf(BusinessModule.POS, BusinessModule.DAMAGED_GOODS, BusinessModule.INVENTORY)
                                BusinessTemplate.CUSTOM -> BusinessModule.values().toSet()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(template.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(template.description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val availableModules = listOf(
                    BusinessModule.POS,
                    BusinessModule.INVENTORY,
                    BusinessModule.TRANSFER,
                    BusinessModule.DAMAGED_GOODS,
                    BusinessModule.FINANCE,
                    BusinessModule.ATTENDANCE,
                    BusinessModule.REPORTS
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pilih Modul Aktif:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                selectedModules = if (selectedModules.size == availableModules.size) {
                                    setOf(BusinessModule.POS)
                                } else {
                                    availableModules.toSet()
                                }
                            }
                        ) {
                            Text(
                                text = if (selectedModules.size == availableModules.size) "Pilih 1" else "Pilih Semua",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "${selectedModules.size}/${availableModules.size} Aktif",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                availableModules.forEach { module ->
                    val isChecked = selectedModules.contains(module)
                    Surface(
                        onClick = {
                            if (isChecked) {
                                if (selectedModules.size > 1) {
                                    selectedModules = selectedModules - module
                                }
                            } else {
                                selectedModules = selectedModules + module
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(module.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(module.description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (businessName.isNotBlank() && selectedModules.isNotEmpty()) {
                        onConfirm(businessName.trim(), selectedTemplate, selectedModules.toList())
                    }
                },
                enabled = businessName.isNotBlank() && selectedModules.isNotEmpty(),
                modifier = Modifier.testTag("btn_save_business")
            ) {
                Text("Simpan Business")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun SwitchBusinessDialog(
    businesses: List<BusinessEntity>,
    activeBusinessId: String?,
    onDismiss: () -> Unit,
    onSelectBusiness: (BusinessEntity) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Pilih Business Aktif",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Data operasional, stok, dan kasir sepenuhnya terisolasi antar bisnis.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                if (businesses.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Belum ada Business yang terdaftar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 350.dp)) {
                        items(businesses) { b ->
                            val isSelected = b.businessId == activeBusinessId
                            Surface(
                                onClick = {
                                    onSelectBusiness(b)
                                    onDismiss()
                                },
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("item_business_${b.name}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(b.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(
                                            text = "Template: ${b.templateType.displayName} • Modul: ${b.activeModules}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Tutup")
                }
            }
        }
    }
}

@Composable
fun CreateTransferDialog(
    businesses: List<BusinessEntity>,
    sourceBusinessId: String,
    items: List<ItemEntity>,
    onDismiss: () -> Unit,
    onConfirm: (sourceId: String, destId: String, itemId: String, qty: Double, notes: String) -> Unit
) {
    var destBusinessId by remember {
        mutableStateOf(businesses.filter { it.businessId != sourceBusinessId }.firstOrNull()?.businessId ?: "")
    }
    var selectedItemId by remember { mutableStateOf(items.firstOrNull()?.itemId ?: "") }
    var quantityText by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }

    val sourceBusiness = businesses.find { it.businessId == sourceBusinessId }
    val selectedItem = items.find { it.itemId == selectedItemId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Buat Permintaan Transfer Barang", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "Transfer hanya diizinkan antar bisnis dengan OWNER yang sama.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Bisnis Sumber: ${sourceBusiness?.name ?: "Unknown"}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Pilih Bisnis Tujuan:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))

                val validDestBusinesses = businesses.filter { it.businessId != sourceBusinessId }
                if (validDestBusinesses.isEmpty()) {
                    Text(
                        "Anda memerlukan minimal 2 Business milik OWNER yang sama untuk melakukan transfer.",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                } else {
                    validDestBusinesses.forEach { b ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { destBusinessId = b.businessId }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = destBusinessId == b.businessId,
                                onClick = { destBusinessId = b.businessId }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(b.name, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Pilih Item Sumber:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))

                if (items.isEmpty()) {
                    Text("Tidak ada item dengan stok di bisnis ini.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                } else {
                    items.forEach { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedItemId = item.itemId }
                                .padding(vertical = 3.dp)
                        ) {
                            RadioButton(
                                selected = selectedItemId == item.itemId,
                                onClick = { selectedItemId = item.itemId }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${item.name} (Tersedia: ${item.stockQuantity} ${item.unit})",
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Jumlah Transfer") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Transfer") },
                    placeholder = { Text("Alasan pemindahan / nomor surat jalan") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val qty = quantityText.toDoubleOrNull() ?: 0.0
            val isValid = destBusinessId.isNotBlank() && selectedItemId.isNotBlank() && qty > 0 &&
                    (selectedItem == null || qty <= selectedItem.stockQuantity)

            Button(
                onClick = {
                    onConfirm(sourceBusinessId, destBusinessId, selectedItemId, qty, notes)
                },
                enabled = isValid
            ) {
                Text("Kirim Request Transfer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun CreateDamagedGoodsDialog(
    items: List<ItemEntity>,
    onDismiss: () -> Unit,
    onConfirm: (itemId: String, location: String, quantity: Double, reason: String) -> Unit
) {
    var selectedItemId by remember { mutableStateOf(items.firstOrNull()?.itemId ?: "") }
    var location by remember { mutableStateOf("Gudang Utama") }
    var quantityText by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("") }

    val selectedItem = items.find { it.itemId == selectedItemId }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Laporan Barang Rusak / Kadaluarsa", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Pilih Item Rusak:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))

                items.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedItemId = item.itemId
                                location = item.location
                            }
                            .padding(vertical = 3.dp)
                    ) {
                        RadioButton(
                            selected = selectedItemId == item.itemId,
                            onClick = {
                                selectedItemId = item.itemId
                                location = item.location
                            }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("${item.name} (Stok: ${item.stockQuantity})", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Lokasi Fisik") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Jumlah Rusak") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Alasan Kerusakan") },
                    placeholder = { Text("Contoh: Kemasan pecah saat pengiriman, expired, dll") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            val qty = quantityText.toDoubleOrNull() ?: 0.0
            val isValid = selectedItemId.isNotBlank() && qty > 0 && reason.isNotBlank() &&
                    (selectedItem == null || qty <= selectedItem.stockQuantity)

            Button(
                onClick = {
                    onConfirm(selectedItemId, location, qty, reason)
                },
                enabled = isValid
            ) {
                Text("Kirim Laporan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun AddItemDialog(
    businessTemplate: BusinessTemplate,
    onDismiss: () -> Unit,
    onConfirm: (name: String, sku: String, category: String, type: String, cost: Double, price: Double, qty: Double, unit: String, loc: String, bom: String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makanan") }
    var type by remember { mutableStateOf("PRODUCT") }
    var costText by remember { mutableStateOf("10000") }
    var priceText by remember { mutableStateOf("15000") }
    var stockText by remember { mutableStateOf("50") }
    var unit by remember { mutableStateOf("pcs") }
    var location by remember { mutableStateOf("Gudang Utama") }
    var recipeBom by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Tambah Item / Produk / Layanan", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Item") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU / Barcode") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Kategori") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("Harga Modal") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Harga Jual") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it },
                        label = { Text("Stok Awal") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Lokasi Simpan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (businessTemplate == BusinessTemplate.FNB) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = recipeBom,
                        onValueChange = { recipeBom = it },
                        label = { Text("Resep / BOM (Rahasia)") },
                        placeholder = { Text("Contoh: Kopi 18g, Susu 150ml, Sirup 10ml") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cost = costText.toDoubleOrNull() ?: 0.0
                    val price = priceText.toDoubleOrNull() ?: 0.0
                    val qty = stockText.toDoubleOrNull() ?: 0.0
                    onConfirm(name, sku, category, type, cost, price, qty, unit, location, recipeBom.ifBlank { null })
                },
                enabled = name.isNotBlank()
            ) {
                Text("Simpan Item")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun AddUserDialog(
    targetRole: UserRole,
    businesses: List<BusinessEntity>,
    onDismiss: () -> Unit,
    onConfirm: (username: String, pass: String, fullName: String, assignedBizIds: List<String>) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var selectedBizIds by remember { mutableStateOf(setOf<String>()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Tambah Pengguna: ", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                RoleBadge(role = targetRole)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Nama Lengkap") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password (Min. 6 Karakter)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (targetRole == UserRole.ADMIN_OWNER) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("Tugaskan Kelola Business:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    businesses.forEach { b ->
                        val isChecked = selectedBizIds.contains(b.businessId)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedBizIds = if (isChecked) selectedBizIds - b.businessId else selectedBizIds + b.businessId
                                }
                                .padding(vertical = 3.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    selectedBizIds = if (it) selectedBizIds + b.businessId else selectedBizIds - b.businessId
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(b.name, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(username, password, fullName, selectedBizIds.toList())
                },
                enabled = username.isNotBlank() && fullName.isNotBlank() && password.length >= 6
            ) {
                Text("Buat Pengguna")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
