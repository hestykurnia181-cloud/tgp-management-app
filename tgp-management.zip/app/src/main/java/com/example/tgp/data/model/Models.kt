package com.example.tgp.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

enum class UserRole {
    MASTER,
    OWNER,
    ADMIN_OWNER,
    LEADER,
    STAFF,
    CASHIER
}

enum class BusinessTemplate(val displayName: String, val description: String) {
    RETAIL("TOKO / RETAIL", "Produk, gudang, stok, POS pembayaran, transfer, absensi, laporan."),
    SERVICE("JASA", "Layanan jasa, kategori, harga, staff komisi, POS, absensi, laporan."),
    FNB("F&B", "Menu, resep BOM, bahan baku, gudang & outlet, POS, transfer, barang rusak."),
    CUSTOM("CUSTOM", "Konfigurasi kustom dengan modul pilihan operasional fleksibel.")
}

enum class BusinessModule(val id: String, val title: String, val description: String) {
    POS("POS", "Point of Sale (Kasir)", "Transaksi kasir, metode pembayaran Cash/Transfer/QRIS."),
    INVENTORY("INVENTORY", "Gudang & Stok", "Manajemen katalog item, lokasi gudang, dan tingkat stok."),
    TRANSFER("TRANSFER", "Transfer Antar Bisnis", "Perpindahan stok aman antar bisnis dalam satu Owner."),
    DAMAGED_GOODS("DAMAGED_GOODS", "Laporan Barang Rusak", "Pencatatan dan approval pemotongan stok rusak."),
    FINANCE("FINANCE", "Keuangan & Ledger", "Buku kas terpisah: Pemasukan, Pengeluaran, Saldo, dan Laba/Rugi."),
    ATTENDANCE("ATTENDANCE", "Absensi & Staff", "Pencatatan kehadiran staff, performer, dan shift kerja."),
    REPORTS("REPORTS", "Laporan & Audit", "Laporan mutasi, penjualan, dan riwayat operasional.")
}

enum class TransferStatus {
    PENDING,
    APPROVED,
    REJECTED
}

enum class DamagedStatus {
    PENDING,
    APPROVED,
    REJECTED
}

enum class PaymentMethod {
    CASH,
    TRANSFER,
    QRIS
}

enum class LedgerType {
    PEMASUKAN,
    PENGELUARAN
}

enum class MutationType {
    INITIAL,
    POS_SALE,
    TRANSFER_IN,
    TRANSFER_OUT,
    DAMAGED_GOODS,
    ADJUSTMENT
}

@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val userId: String = UUID.randomUUID().toString(),
    val username: String,
    val passwordHash: String,
    val salt: String,
    val fullName: String,
    val role: UserRole,
    val ownerId: String? = null, // Links to OWNER user
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "businesses",
    indices = [Index(value = ["ownerId"])]
)
data class BusinessEntity(
    @PrimaryKey val businessId: String = UUID.randomUUID().toString(),
    val ownerId: String, // Strict OWNER relation
    val name: String,
    val templateType: BusinessTemplate,
    val activeModules: String, // Comma separated BusinessModule ids (Max 2)
    val createdAt: Long = System.currentTimeMillis()
) {
    fun hasModule(module: BusinessModule): Boolean {
        return activeModules.split(",").map { it.trim() }.contains(module.id)
    }

    fun getModuleList(): List<BusinessModule> {
        val ids = activeModules.split(",").map { it.trim() }
        return BusinessModule.values().filter { ids.contains(it.id) }
    }
}

@Entity(
    tableName = "admin_business_assignments",
    indices = [Index(value = ["userId", "businessId"], unique = true)]
)
data class AdminBusinessAssignmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val businessId: String,
    val assignedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "staff_business_bindings",
    indices = [Index(value = ["userId", "businessId"], unique = true)]
)
data class StaffBusinessBindingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val businessId: String,
    val role: UserRole, // LEADER, STAFF, CASHIER
    val boundAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "items",
    indices = [Index(value = ["businessId"])]
)
data class ItemEntity(
    @PrimaryKey val itemId: String = UUID.randomUUID().toString(),
    val businessId: String, // Strict business isolation
    val name: String,
    val sku: String,
    val category: String,
    val type: String, // "PRODUCT", "SERVICE", "RAW_MATERIAL", "MENU_DISH"
    val costPrice: Double, // Modal / Capital - HIDDEN FROM CASHIER
    val sellingPrice: Double,
    val stockQuantity: Double,
    val unit: String = "pcs",
    val recipeBom: String? = null, // Secret Recipe / BOM - HIDDEN FROM CASHIER
    val location: String = "Gudang Utama",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_mutations",
    indices = [Index(value = ["businessId"]), Index(value = ["itemId"])]
)
data class StockMutationEntity(
    @PrimaryKey val mutationId: String = UUID.randomUUID().toString(),
    val businessId: String,
    val itemId: String,
    val itemName: String,
    val changeQty: Double,
    val finalQty: Double,
    val type: MutationType,
    val referenceId: String,
    val note: String,
    val timestamp: Long = System.currentTimeMillis(),
    val performedBy: String
)

@Entity(
    tableName = "ledger_transactions",
    indices = [Index(value = ["businessId"])]
)
data class LedgerTransactionEntity(
    @PrimaryKey val transactionId: String = UUID.randomUUID().toString(),
    val businessId: String,
    val type: LedgerType,
    val category: String,
    val amount: Double,
    val referenceId: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val createdBy: String
)

@Entity(
    tableName = "transfers",
    indices = [Index(value = ["ownerId"]), Index(value = ["transferReference"])]
)
data class TransferEntity(
    @PrimaryKey val transferId: String = UUID.randomUUID().toString(),
    val transferReference: String, // Shared transfer reference
    val sourceBusinessId: String,
    val sourceBusinessName: String,
    val sourceLocation: String,
    val destBusinessId: String,
    val destBusinessName: String,
    val destLocation: String,
    val itemId: String,
    val itemName: String,
    val quantity: Double,
    val unitValue: Double,
    val totalValue: Double,
    val ownerId: String, // Must be identical for source and destination!
    val status: TransferStatus = TransferStatus.PENDING,
    val requestedBy: String,
    val approvedBy: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val processedAt: Long? = null,
    val notes: String = ""
)

@Entity(
    tableName = "damaged_goods_reports",
    indices = [Index(value = ["businessId"])]
)
data class DamagedGoodsReportEntity(
    @PrimaryKey val reportId: String = UUID.randomUUID().toString(),
    val businessId: String,
    val location: String,
    val itemId: String,
    val itemName: String,
    val quantity: Double,
    val lossValue: Double,
    val reason: String,
    val reportedBy: String,
    val status: DamagedStatus = DamagedStatus.PENDING,
    val approvedBy: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val processedAt: Long? = null
) {
    val reportReference: String get() = "DMG-${reportId.take(8).uppercase()}"
}

@Entity(
    tableName = "sales_orders",
    indices = [Index(value = ["businessId"])]
)
data class SaleOrderEntity(
    @PrimaryKey val saleId: String = UUID.randomUUID().toString(),
    val receiptNumber: String,
    val businessId: String,
    val cashierName: String,
    val totalAmount: Double,
    val paymentMethod: PaymentMethod,
    val itemsSummary: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "attendances",
    indices = [Index(value = ["businessId"]), Index(value = ["userId"])]
)
data class AttendanceEntity(
    @PrimaryKey val attendanceId: String = UUID.randomUUID().toString(),
    val businessId: String,
    val userId: String,
    val userName: String,
    val type: String, // "CHECK_IN", "CHECK_OUT"
    val timestamp: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(
    tableName = "audit_logs"
)
data class AuditLogEntity(
    @PrimaryKey val logId: String = UUID.randomUUID().toString(),
    val userId: String,
    val username: String,
    val role: UserRole,
    val businessId: String? = null,
    val action: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)
