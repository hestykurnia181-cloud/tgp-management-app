package com.example.tgp.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.tgp.data.model.*
import com.example.tgp.data.repository.UserSession
import com.example.ui.theme.*

@Composable
fun RoleBadge(role: UserRole, modifier: Modifier = Modifier) {
    val (bg, fg, borderCol) = when (role) {
        UserRole.MASTER -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), Color(0xFFFDE68A))
        UserRole.OWNER -> Triple(Color(0xFFEDE9FE), Color(0xFF6D28D9), Color(0xFFDDD6FE))
        UserRole.ADMIN_OWNER -> Triple(Color(0xFFDBEAFE), Color(0xFF1D4ED8), Color(0xFFBFDBFE))
        UserRole.LEADER -> Triple(Color(0xFFCFFAFE), Color(0xFF0E7490), Color(0xFFA5F3FC))
        UserRole.STAFF -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), Color(0xFFBBF7D0))
        UserRole.CASHIER -> Triple(Color(0xFFFCE7F3), Color(0xFFBE185D), Color(0xFFFBCFE8))
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, borderCol),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = role.name,
                color = fg,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bg, fg, borderCol) = when (status.uppercase()) {
        "APPROVED" -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), Color(0xFFBBF7D0))
        "REJECTED" -> Triple(Color(0xFFFEE2E2), Color(0xFFB91C1C), Color(0xFFFECACA))
        else -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), Color(0xFFFDE68A)) // PENDING
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, borderCol),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = status,
                color = fg,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ModulePill(module: BusinessModule, modifier: Modifier = Modifier) {
    val modColor = when (module) {
        BusinessModule.POS -> Color(0xFF2563EB)
        BusinessModule.INVENTORY -> Color(0xFF0D9488)
        BusinessModule.TRANSFER -> Color(0xFF7C3AED)
        BusinessModule.DAMAGED_GOODS -> Color(0xFFDC2626)
        BusinessModule.FINANCE -> Color(0xFF16A34A)
        BusinessModule.ATTENDANCE -> Color(0xFFEA580C)
        BusinessModule.REPORTS -> Color(0xFF4F46E5)
    }

    Surface(
        color = modColor.copy(alpha = 0.10f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, modColor.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = when (module) {
                    BusinessModule.POS -> Icons.Default.PointOfSale
                    BusinessModule.INVENTORY -> Icons.Default.Inventory2
                    BusinessModule.TRANSFER -> Icons.Default.SwapHoriz
                    BusinessModule.DAMAGED_GOODS -> Icons.Default.ReportProblem
                    BusinessModule.FINANCE -> Icons.Default.AccountBalance
                    BusinessModule.ATTENDANCE -> Icons.Default.Badge
                    BusinessModule.REPORTS -> Icons.Default.Assessment
                },
                contentDescription = null,
                tint = modColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = module.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = modColor
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TgpTopBar(
    session: UserSession?,
    activeBusiness: BusinessEntity?,
    onSwitchBusinessClick: () -> Unit,
    onLogoutClick: () -> Unit,
    onBackClick: (() -> Unit)? = null,
    title: String? = null
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .windowInsetsPadding(WindowInsets.statusBars)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    if (onBackClick != null) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .testTag("btn_top_back")
                                .size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Kembali",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    // Modern App Logo Emblem
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0F172A), Color(0xFF1E3A8A), Color(0xFF2563EB))
                                )
                            )
                            .border(1.dp, Color(0xFF60A5FA).copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_tgp_logo),
                            contentDescription = "TGP",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = title ?: "TGP Management",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (session != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = session.user.fullName,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                RoleBadge(role = session.user.role)
                            }
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    // Modern Business Switcher Pill (for roles that manage businesses)
                    if (session != null && session.user.role != UserRole.MASTER) {
                        Surface(
                            onClick = onSwitchBusinessClick,
                            shape = RoundedCornerShape(20.dp),
                            color = if (activeBusiness != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                            border = BorderStroke(
                                1.dp,
                                if (activeBusiness != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.error.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .testTag("btn_switch_business")
                                .padding(end = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = null,
                                    tint = if (activeBusiness != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = activeBusiness?.name ?: "Pilih Bisnis",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (activeBusiness != null) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 110.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = if (activeBusiness != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = onLogoutClick,
                        modifier = Modifier
                            .testTag("btn_logout")
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Logout",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(accentColor.copy(alpha = 0.16f), accentColor.copy(alpha = 0.06f))
                        )
                    )
                    .border(1.dp, accentColor.copy(alpha = 0.2f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = value,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (subtitle != null) {
                    Spacer(modifier = Modifier.height(1.dp))
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun TgpBottomBar(
    role: UserRole,
    activeBusiness: BusinessEntity?,
    currentScreen: com.example.tgp.ui.viewmodel.AppScreen,
    onNavigate: (com.example.tgp.ui.viewmodel.AppScreen) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        shadowElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp,
            modifier = Modifier.height(64.dp)
        ) {
            when (role) {
                UserRole.MASTER -> {
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.MASTER_DASHBOARD,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.MASTER_DASHBOARD) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Platform") },
                        label = { Text("Platform", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.AUDIT_LOG_VIEWER,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.AUDIT_LOG_VIEWER) },
                        icon = { Icon(Icons.Default.Security, contentDescription = "Audit Log") },
                        label = { Text("Audit Log", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
                UserRole.OWNER -> {
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.OWNER_DASHBOARD,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.OWNER_DASHBOARD) },
                        icon = { Icon(Icons.Default.Business, contentDescription = "Bisnis") },
                        label = { Text("Bisnis", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.BUSINESS_HOME,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.BUSINESS_HOME) },
                        icon = { Icon(Icons.Default.Storefront, contentDescription = "Operasional") },
                        label = { Text("Operasional", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.APPROVAL_MODULE,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.APPROVAL_MODULE) },
                        icon = { Icon(Icons.Default.VerifiedUser, contentDescription = "Approval") },
                        label = { Text("Approval", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.FINANCE_MODULE,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.FINANCE_MODULE) },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Keuangan") },
                        label = { Text("Keuangan", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
                UserRole.ADMIN_OWNER, UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER -> {
                    NavigationBarItem(
                        selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.BUSINESS_HOME,
                        onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.BUSINESS_HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Beranda") },
                        label = { Text("Beranda", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                    )

                    // Show POS if POS is enabled on active business
                    if (activeBusiness?.hasModule(BusinessModule.POS) == true) {
                        NavigationBarItem(
                            selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.POS_MODULE,
                            onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.POS_MODULE) },
                            icon = { Icon(Icons.Default.PointOfSale, contentDescription = "POS") },
                            label = { Text("Kasir", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }

                    // Show Inventory if enabled and not cashier
                    if (activeBusiness?.hasModule(BusinessModule.INVENTORY) == true) {
                        NavigationBarItem(
                            selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.INVENTORY_MODULE,
                            onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.INVENTORY_MODULE) },
                            icon = { Icon(Icons.Default.Inventory2, contentDescription = "Stok") },
                            label = { Text("Stok", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }

                    if (role in listOf(UserRole.ADMIN_OWNER, UserRole.LEADER)) {
                        NavigationBarItem(
                            selected = currentScreen == com.example.tgp.ui.viewmodel.AppScreen.APPROVAL_MODULE,
                            onClick = { onNavigate(com.example.tgp.ui.viewmodel.AppScreen.APPROVAL_MODULE) },
                            icon = { Icon(Icons.Default.FactCheck, contentDescription = "Approval") },
                            label = { Text("Approval", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }
            }
        }
    }
}
