package com.example.tgp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgp.data.model.LedgerType
import com.example.tgp.data.model.UserRole
import com.example.tgp.ui.components.StatCard
import com.example.tgp.ui.viewmodel.TgpViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun FinanceScreen(viewModel: TgpViewModel) {
    val ledger by viewModel.activeLedger.collectAsState()
    val session by viewModel.currentSession.collectAsState()
    val activeBiz by viewModel.activeBusiness.collectAsState()

    val userRole = session?.user?.role ?: UserRole.STAFF
    val isCashier = userRole == UserRole.CASHIER

    var showManualEntryDialog by remember { mutableStateOf(false) }
    var selectedTypeFilter by remember { mutableStateOf<LedgerType?>(null) }

    // STRICT ROLE ACCESS CONTROL
    if (isCashier) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Akses Keuangan Terbatas",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Role CASHIER tidak memiliki izin untuk melihat buku besar, modal, atau ringkasan laba/rugi.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }
        return
    }

    val totalIncome = ledger.filter { it.type == LedgerType.PEMASUKAN }.sumOf { it.amount }
    val totalExpense = ledger.filter { it.type == LedgerType.PENGELUARAN }.sumOf { it.amount }
    val netBalance = totalIncome - totalExpense

    val filteredLedger = remember(ledger, selectedTypeFilter) {
        if (selectedTypeFilter == null) ledger
        else ledger.filter { it.type == selectedTypeFilter }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Pembukuan & Kas Keuangan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Buku Kas: ${activeBiz?.name ?: "Pilih Bisnis"}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (userRole in listOf(UserRole.OWNER, UserRole.ADMIN_OWNER, UserRole.LEADER)) {
                    Button(
                        onClick = { showManualEntryDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_add_manual_ledger")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Catat Transaksi", fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Pemasukan",
                    value = "Rp ${totalIncome.toLong()}",
                    icon = Icons.Default.TrendingUp,
                    accentColor = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Total Pengeluaran",
                    value = "Rp ${totalExpense.toLong()}",
                    icon = Icons.Default.TrendingDown,
                    accentColor = Color(0xFFDC2626),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column {
                        Text("Saldo Kas Bersih", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("Rp ${netBalance.toLong()}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }

                    Surface(
                        color = if (netBalance >= 0) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (netBalance >= 0) "SURPLUS" else "DEFISIT",
                            color = if (netBalance >= 0) Color(0xFF15803D) else Color(0xFFB91C1C),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Mutasi Buku Kas", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedTypeFilter == null,
                        onClick = { selectedTypeFilter = null },
                        label = { Text("Semua", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedTypeFilter == LedgerType.PEMASUKAN,
                        onClick = { selectedTypeFilter = LedgerType.PEMASUKAN },
                        label = { Text("Masuk", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedTypeFilter == LedgerType.PENGELUARAN,
                        onClick = { selectedTypeFilter = LedgerType.PENGELUARAN },
                        label = { Text("Keluar", fontSize = 11.sp) }
                    )
                }
            }
        }

        if (filteredLedger.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(28.dp), contentAlignment = Alignment.Center) {
                        Text("Belum ada mutasi keuangan tercatat pada bisnis ini.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            items(filteredLedger) { entry ->
                val isIncome = entry.type == LedgerType.PEMASUKAN
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isIncome) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (isIncome) Color(0xFF15803D) else Color(0xFFB91C1C),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(entry.category, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(entry.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "${SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(entry.timestamp))} • ${entry.createdBy}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Text(
                            text = "${if (isIncome) "+" else "-"}Rp ${entry.amount.toLong()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isIncome) Color(0xFF15803D) else Color(0xFFB91C1C)
                        )
                    }
                }
            }
        }
    }

    if (showManualEntryDialog) {
        var entryType by remember { mutableStateOf(LedgerType.PENGELUARAN) }
        var category by remember { mutableStateOf("Operasional") }
        var amountText by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showManualEntryDialog = false },
            title = {
                Text("Catat Transaksi Kas Manual", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = entryType == LedgerType.PEMASUKAN,
                            onClick = {
                                entryType = LedgerType.PEMASUKAN
                                category = "Pemasukan Lainnya"
                            },
                            label = { Text("Pemasukan (+)", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = entryType == LedgerType.PENGELUARAN,
                            onClick = {
                                entryType = LedgerType.PENGELUARAN
                                category = "Biaya Operasional"
                            },
                            label = { Text("Pengeluaran (-)", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Kategori") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Nominal (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Keterangan") },
                        placeholder = { Text("Contoh: Pembelian listrik / ATK") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        viewModel.addManualLedgerEntry(entryType, category, amt, description)
                        showManualEntryDialog = false
                    },
                    enabled = amt > 0 && category.isNotBlank()
                ) {
                    Text("Simpan Transaksi")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualEntryDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}
