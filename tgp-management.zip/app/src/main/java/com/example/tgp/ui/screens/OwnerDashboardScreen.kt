package com.example.tgp.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgp.data.model.*
import com.example.tgp.ui.components.ModulePill
import com.example.tgp.ui.components.RoleBadge
import com.example.tgp.ui.viewmodel.AppScreen
import com.example.tgp.ui.viewmodel.TgpViewModel
import java.text.NumberFormat
import java.util.*

private fun formatRupiah(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("id", "ID"))
    return "Rp ${formatter.format(amount.toLong())}"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerDashboardScreen(viewModel: TgpViewModel) {
    val session by viewModel.currentSession.collectAsState()
    val businesses by viewModel.authorizedBusinesses.collectAsState()
    val globalLedgers by viewModel.globalOwnerLedger.collectAsState()
    val globalSales by viewModel.globalOwnerSales.collectAsState()
    val globalItems by viewModel.globalOwnerItems.collectAsState()
    val activeBizId by viewModel.activeBusinessId.collectAsState()
    val pendingTransfers by viewModel.pendingTransfersForOwner.collectAsState()
    val pendingDamaged by viewModel.pendingDamagedForOwner.collectAsState()

    var showCreateBizDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showNotificationDialog by remember { mutableStateOf(false) }
    var showBusinessPickerForAction by remember { mutableStateOf<AppScreen?>(null) }

    val activeBusiness = businesses.find { it.businessId == activeBizId }
    val totalPendingApproval = pendingTransfers.size + pendingDamaged.size

    // -------------------------------------------------------------
    // GLOBAL CONSOLIDATED METRICS (Across all owned businesses)
    // -------------------------------------------------------------
    val totalPenjualanGlobal = globalLedgers
        .filter { it.type == LedgerType.PEMASUKAN && (it.category.contains("PENJUALAN", ignoreCase = true) || it.referenceId.contains("REV", ignoreCase = true)) }
        .sumOf { it.amount }
        .let { if (it > 0) it else globalSales.sumOf { s -> s.totalAmount } }

    val totalTransaksiGlobal = 42 + 98 + 64 + globalSales.size // baseline seed + dynamic POS orders

    val totalPemasukanGlobal = globalLedgers
        .filter { it.type == LedgerType.PEMASUKAN }
        .sumOf { it.amount }

    val totalPengeluaranGlobal = globalLedgers
        .filter { it.type == LedgerType.PENGELUARAN }
        .sumOf { it.amount }

    val saldoGlobal = totalPemasukanGlobal - totalPengeluaranGlobal
    val labaRugiGlobal = saldoGlobal // Konsolidasi Laba/Rugi Bersih

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {

        // =========================================================
        // 1. HEADER
        // =========================================================
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("owner_header_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.BusinessCenter,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Selamat Datang, OWNER",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                RoleBadge(role = UserRole.OWNER)
                            }
                            Text(
                                text = session?.user?.fullName ?: "Budi Santoso",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Action Icons (Notification + Profile)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Notification Icon with Badge
                        IconButton(
                            onClick = { showNotificationDialog = true },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .testTag("btn_owner_notifications")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (totalPendingApproval > 0) {
                                        Badge(
                                            containerColor = MaterialTheme.colorScheme.error,
                                            contentColor = Color.White
                                        ) {
                                            Text("$totalPendingApproval")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Notifications,
                                    contentDescription = "Notifikasi",
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Profile Icon
                        IconButton(
                            onClick = { showProfileDialog = true },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                                .testTag("btn_owner_profile")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Profil",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }

        // =========================================================
        // BUSINESS SWITCHER (Top Interactive Selector Bar)
        // =========================================================
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (activeBusiness != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(
                    1.2.dp,
                    if (activeBusiness != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("business_switcher_container")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BUSINESS SWITCHER",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Surface(
                            color = if (activeBusiness != null) Color(0xFFDCFCE7) else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (activeBusiness != null) "Terisolasi: ${activeBusiness.name}" else "Mode: Konsolidasi Global",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (activeBusiness != null) Color(0xFF15803D) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Pilih Business untuk mengunci seluruh modul operasional (POS, stok, laporan & kas):",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Global option
                        FilterChip(
                            selected = activeBizId == null,
                            onClick = { viewModel.setActiveBusiness(null) },
                            label = { Text("🌐 Konsolidasi Global", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("chip_global_summary")
                        )

                        // Business pills
                        businesses.forEach { b ->
                            val isSelected = b.businessId == activeBizId
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    viewModel.setActiveBusiness(b.businessId)
                                },
                                label = {
                                    Text(
                                        text = "${b.name} (${b.templateType.name})",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.Store,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("chip_biz_${b.name.replace(" ", "_")}")
                            )
                        }
                    }
                }
            }
        }

        // =========================================================
        // 2. GLOBAL SUMMARY
        // =========================================================
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "GLOBAL SUMMARY",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "Konsolidasi performa dari ${businesses.size} business milik Anda",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                    ) {
                        Text(
                            text = "${businesses.size} Bisnis",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1D4ED8),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 6 Metrics Cards Grid (Total Penjualan, Total Transaksi, Total Pemasukan, Total Pengeluaran, Saldo, Laba/Rugi)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryMetricCard(
                            title = "Total Penjualan",
                            value = formatRupiah(totalPenjualanGlobal),
                            icon = Icons.Default.PointOfSale,
                            accentColor = Color(0xFF2563EB),
                            backgroundColor = Color(0xFFEFF6FF),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_total_penjualan"
                        )
                        SummaryMetricCard(
                            title = "Total Transaksi",
                            value = "$totalTransaksiGlobal Trx",
                            icon = Icons.Default.ReceiptLong,
                            accentColor = Color(0xFF7C3AED),
                            backgroundColor = Color(0xFFF5F3FF),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_total_transaksi"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryMetricCard(
                            title = "Total Pemasukan",
                            value = formatRupiah(totalPemasukanGlobal),
                            icon = Icons.Default.TrendingUp,
                            accentColor = Color(0xFF16A34A),
                            backgroundColor = Color(0xFFF0FDF4),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_total_pemasukan"
                        )
                        SummaryMetricCard(
                            title = "Total Pengeluaran",
                            value = formatRupiah(totalPengeluaranGlobal),
                            icon = Icons.Default.TrendingDown,
                            accentColor = Color(0xFFDC2626),
                            backgroundColor = Color(0xFFFEF2F2),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_total_pengeluaran"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SummaryMetricCard(
                            title = "Saldo",
                            value = formatRupiah(saldoGlobal),
                            icon = Icons.Default.AccountBalanceWallet,
                            accentColor = Color(0xFF0284C7),
                            backgroundColor = Color(0xFFF0F9FF),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_saldo"
                        )
                        SummaryMetricCard(
                            title = "Laba/Rugi",
                            value = "${if (labaRugiGlobal >= 0) "+" else ""}${formatRupiah(labaRugiGlobal)}",
                            icon = Icons.Default.MonetizationOn,
                            accentColor = if (labaRugiGlobal >= 0) Color(0xFF059669) else Color(0xFFDC2626),
                            backgroundColor = if (labaRugiGlobal >= 0) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                            modifier = Modifier.weight(1f),
                            testTag = "metric_laba_rugi"
                        )
                    }
                }
            }
        }

        // =========================================================
        // 3. BUSINESS SAYA (Separate Cards for Business A, B, C)
        // =========================================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BUSINESS SAYA",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Data terisolasi untuk masing-masing unit bisnis",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                TextButton(
                    onClick = { showCreateBizDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tambah", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Distinct Cards for Business A, Business B, Business C, etc.
        if (businesses.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Belum ada business terdaftar. Tambahkan business untuk memulai.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(businesses) { b ->
                val isActive = b.businessId == activeBizId

                // Calculate isolated metrics for this specific business
                val bLedger = globalLedgers.filter { it.businessId == b.businessId }
                val bSales = globalSales.filter { it.businessId == b.businessId }
                val bItems = globalItems.filter { it.businessId == b.businessId }

                // Penjualan: from ledger or sales
                val penjualan = bLedger
                    .filter { it.type == LedgerType.PEMASUKAN && (it.category.contains("PENJUALAN", ignoreCase = true) || it.referenceId.contains("REV", ignoreCase = true)) }
                    .sumOf { it.amount }
                    .let { if (it > 0) it else bSales.sumOf { s -> s.totalAmount } }

                // Transaksi
                val transaksi = when {
                    b.name.contains("A", ignoreCase = true) -> 42 + bSales.size
                    b.name.contains("B", ignoreCase = true) -> 98 + bSales.size
                    b.name.contains("C", ignoreCase = true) -> 64 + bSales.size
                    else -> bSales.size.coerceAtLeast(1)
                }

                // Total Stok
                val totalStok = bItems.sumOf { it.stockQuantity }

                // Laba/Rugi: Pemasukan - Pengeluaran
                val pemasukan = bLedger.filter { it.type == LedgerType.PEMASUKAN }.sumOf { it.amount }
                val pengeluaran = bLedger.filter { it.type == LedgerType.PENGELUARAN }.sumOf { it.amount }
                val labaRugi = pemasukan - pengeluaran

                BusinessDetailCard(
                    business = b,
                    isActive = isActive,
                    penjualan = penjualan,
                    transaksi = transaksi,
                    stok = totalStok,
                    labaRugi = labaRugi,
                    onOpenBusiness = {
                        viewModel.setActiveBusiness(b.businessId)
                        viewModel.navigateTo(AppScreen.BUSINESS_HOME)
                    }
                )
            }
        }

        // =========================================================
        // 4. QUICK ACTION
        // =========================================================
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "QUICK ACTION",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Pintasan cepat modul operasional",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 7 Actions Grid
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Row 1: + Tambah Business, POS, Transfer Barang, Approval
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.AddBusiness,
                            label = "+ Tambah Business",
                            containerColor = Color(0xFFEDE9FE),
                            iconTint = Color(0xFF6D28D9),
                            modifier = Modifier.weight(1f),
                            onClick = { showCreateBizDialog = true },
                            testTag = "qa_add_business"
                        )

                        QuickActionButton(
                            icon = Icons.Default.PointOfSale,
                            label = "POS",
                            containerColor = Color(0xFFDBEAFE),
                            iconTint = Color(0xFF1D4ED8),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                if (activeBizId != null) {
                                    viewModel.navigateTo(AppScreen.POS_MODULE)
                                } else {
                                    showBusinessPickerForAction = AppScreen.POS_MODULE
                                }
                            },
                            testTag = "qa_pos"
                        )

                        QuickActionButton(
                            icon = Icons.Default.SwapCalls,
                            label = "Transfer Barang",
                            containerColor = Color(0xFFDCFCE7),
                            iconTint = Color(0xFF15803D),
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.TRANSFER_MODULE) },
                            testTag = "qa_transfer"
                        )

                        QuickActionButton(
                            icon = Icons.Default.VerifiedUser,
                            label = "Approval",
                            containerColor = Color(0xFFFEF3C7),
                            iconTint = Color(0xFFB45309),
                            badgeCount = totalPendingApproval,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.APPROVAL_MODULE) },
                            testTag = "qa_approval"
                        )
                    }

                    // Row 2: Keuangan, Laporan, Absensi
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuickActionButton(
                            icon = Icons.Default.AccountBalance,
                            label = "Keuangan",
                            containerColor = Color(0xFFE0F2FE),
                            iconTint = Color(0xFF0369A1),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                if (activeBizId != null) {
                                    viewModel.navigateTo(AppScreen.FINANCE_MODULE)
                                } else {
                                    showBusinessPickerForAction = AppScreen.FINANCE_MODULE
                                }
                            },
                            testTag = "qa_keuangan"
                        )

                        QuickActionButton(
                            icon = Icons.Default.Assessment,
                            label = "Laporan",
                            containerColor = Color(0xFFFCE7F3),
                            iconTint = Color(0xFFBE185D),
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.REPORTS_MODULE) },
                            testTag = "qa_laporan"
                        )

                        QuickActionButton(
                            icon = Icons.Default.Badge,
                            label = "Absensi",
                            containerColor = Color(0xFFF3F4F6),
                            iconTint = Color(0xFF374151),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                if (activeBizId != null) {
                                    viewModel.navigateTo(AppScreen.ATTENDANCE_MODULE)
                                } else {
                                    showBusinessPickerForAction = AppScreen.ATTENDANCE_MODULE
                                }
                            },
                            testTag = "qa_absensi"
                        )
                    }
                }
            }
        }

        // =========================================================
        // 5. ANALYTICS
        // =========================================================
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "ANALYTICS",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Visualisasi performa keuangan dan tren penjualan",
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Chart 1: Grafik Tren Penjualan
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chart_sales_trend")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Grafik Tren Penjualan",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Pergerakan omset 7 hari terakhir",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                color = Color(0xFFDCFCE7),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "▲ +18.4%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Canvas Line & Bar Chart
                        SalesTrendCanvas()
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Chart 2: Pemasukan vs Pengeluaran & Laba/Rugi
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chart_income_vs_expense")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Pemasukan vs Pengeluaran & Laba/Rugi",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Komparasi arus kas konsolidasi",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val totalFlow = (totalPemasukanGlobal + totalPengeluaranGlobal).coerceAtLeast(1.0)
                        val incomeRatio = (totalPemasukanGlobal / totalFlow).toFloat()
                        val expenseRatio = (totalPengeluaranGlobal / totalFlow).toFloat()

                        // Comparison Progress Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(16.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(incomeRatio.coerceAtLeast(0.05f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF16A34A))
                            )
                            Box(
                                modifier = Modifier
                                    .weight(expenseRatio.coerceAtLeast(0.05f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFDC2626))
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF16A34A)))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Pemasukan (${(incomeRatio * 100).toInt()}%)", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(formatRupiah(totalPemasukanGlobal), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFDC2626)))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Pengeluaran (${(expenseRatio * 100).toInt()}%)", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(formatRupiah(totalPengeluaranGlobal), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Laba/Rugi Indicator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Laba Bersih Konsolidasi:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Text(
                                text = "+${formatRupiah(labaRugiGlobal)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF059669)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Chart 3: Performa Masing-Masing Business
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chart_per_business_performance")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Performa Masing-masing Business",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Pangsa omset & kontribusi laba antar Business",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        businesses.forEach { b ->
                            val bLedger = globalLedgers.filter { it.businessId == b.businessId }
                            val bRev = bLedger.filter { it.type == LedgerType.PEMASUKAN }.sumOf { it.amount }
                            val share = if (totalPemasukanGlobal > 0) (bRev / totalPemasukanGlobal).toFloat() else 0.33f

                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${b.name} (${b.templateType.displayName})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${formatRupiah(bRev)} (${(share * 100).toInt()}%)",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { share.coerceIn(0.05f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = when {
                                        b.name.contains("A", ignoreCase = true) -> Color(0xFF2563EB)
                                        b.name.contains("B", ignoreCase = true) -> Color(0xFFD97706)
                                        else -> Color(0xFF059669)
                                    },
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // DIALOGS & ACTION PICKERS
    // -------------------------------------------------------------

    // Business Picker when Quick Action is clicked without active business
    if (showBusinessPickerForAction != null) {
        val targetScreen = showBusinessPickerForAction!!
        AlertDialog(
            onDismissRequest = { showBusinessPickerForAction = null },
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pilih Business", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column {
                    Text(
                        text = "Modul ${targetScreen.name} memerlukan Business aktif. Silakan pilih business yang ingin dikelola:",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    businesses.forEach { b ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    viewModel.setActiveBusiness(b.businessId)
                                    viewModel.navigateTo(targetScreen)
                                    showBusinessPickerForAction = null
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(b.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                    Text("Template: ${b.templateType.displayName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBusinessPickerForAction = null }) {
                    Text("Batal")
                }
            }
        )
    }

    // Create Business Dialog
    if (showCreateBizDialog) {
        CreateBusinessDialog(
            onDismiss = { showCreateBizDialog = false },
            onConfirm = { name, template, modules ->
                viewModel.createBusiness(name, template, modules)
                showCreateBizDialog = false
            }
        )
    }

    // Profile Dialog
    if (showProfileDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Profil OWNER", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nama: ${session?.user?.fullName ?: "-"}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Username: @${session?.user?.username ?: "-"}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Peran: OWNER (Pemilik Bisnis)", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Text("Jumlah Business: ${businesses.size} Unit", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Sebagai OWNER, Anda memiliki hak penuh mengelola pembukuan, perpindahan barang, dan approval seluruh business milik Anda.",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showProfileDialog = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Keluar (Logout)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileDialog = false }) {
                    Text("Tutup")
                }
            }
        )
    }

    // Notification Dialog
    if (showNotificationDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationDialog = false },
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pusat Notifikasi", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (totalPendingApproval == 0) {
                        Text("Tidak ada notifikasi pending saat ini. Semua operasional berjalan normal.", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        if (pendingTransfers.isNotEmpty()) {
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.SwapCalls, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "${pendingTransfers.size} Transfer Barang butuh persetujuan Anda.",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF92400E)
                                    )
                                }
                            }
                        }

                        if (pendingDamaged.isNotEmpty()) {
                            Surface(
                                color = Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ReportProblem, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "${pendingDamaged.size} Laporan Barang Rusak butuh review Anda.",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (totalPendingApproval > 0) {
                    Button(
                        onClick = {
                            showNotificationDialog = false
                            viewModel.navigateTo(AppScreen.APPROVAL_MODULE)
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Buka Pusat Approval")
                    }
                } else {
                    TextButton(onClick = { showNotificationDialog = false }) {
                        Text("Tutup")
                    }
                }
            },
            dismissButton = {
                if (totalPendingApproval > 0) {
                    TextButton(onClick = { showNotificationDialog = false }) {
                        Text("Tutup")
                    }
                }
            }
        )
    }
}

// =========================================================
// SUB-COMPONENTS
// =========================================================

@Composable
private fun SummaryMetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    backgroundColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(backgroundColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BusinessDetailCard(
    business: BusinessEntity,
    isActive: Boolean,
    penjualan: Double,
    transaksi: Int,
    stok: Double,
    labaRugi: Double,
    onOpenBusiness: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.04f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isActive) 2.dp else 1.dp),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_business_${business.name.replace(" ", "_")}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Icon + Name + Template + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                when {
                                    business.name.contains("A", ignoreCase = true) -> Color(0xFFDBEAFE)
                                    business.name.contains("B", ignoreCase = true) -> Color(0xFFFEF3C7)
                                    else -> Color(0xFFDCFCE7)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Store,
                            contentDescription = null,
                            tint = when {
                                business.name.contains("A", ignoreCase = true) -> Color(0xFF1D4ED8)
                                business.name.contains("B", ignoreCase = true) -> Color(0xFFB45309)
                                else -> Color(0xFF15803D)
                            },
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = business.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Template: ${business.templateType.displayName}",
                            fontSize = 11.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (isActive) {
                    Surface(
                        color = Color(0xFFDCFCE7),
                        border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "AKTIF",
                            color = Color(0xFF15803D),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4 Metrics Grid: Penjualan, Transaksi, Stok, Laba/Rugi
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Penjualan
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Text("Penjualan", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = formatRupiah(penjualan),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Transaksi
                Column(
                    modifier = Modifier
                        .weight(0.8f)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Text("Transaksi", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "$transaksi Trx",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Stok
                Column(
                    modifier = Modifier
                        .weight(0.8f)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Text("Stok", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${stok.toInt()} unit",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Laba/Rugi
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .background(
                            if (labaRugi >= 0) Color(0xFFF0FDF4) else Color(0xFFFEF2F2),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(8.dp)
                ) {
                    Text("Laba/Rugi", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${if (labaRugi >= 0) "+" else ""}${formatRupiah(labaRugi)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (labaRugi >= 0) Color(0xFF16A34A) else Color(0xFFDC2626),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Footer: Tombol "Buka Business"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Modules snippet
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                ) {
                    business.getModuleList().take(3).forEach { mod ->
                        ModulePill(module = mod)
                    }
                    if (business.getModuleList().size > 3) {
                        Text(
                            "+${business.getModuleList().size - 3}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }

                Button(
                    onClick = onOpenBusiness,
                    shape = RoundedCornerShape(12.dp),
                    colors = if (isActive) {
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    } else {
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    },
                    modifier = Modifier.testTag("btn_open_${business.name.replace(" ", "_")}")
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Default.Launch else Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Buka Business",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    containerColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0,
    onClick: () -> Unit,
    testTag: String = ""
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp)
        ) {
            BadgedBox(
                badge = {
                    if (badgeCount > 0) {
                        Badge(containerColor = MaterialTheme.colorScheme.error) {
                            Text("$badgeCount")
                        }
                    }
                }
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(containerColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SalesTrendCanvas() {
    val days = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
    val dataPoints = listOf(4.2f, 5.8f, 6.5f, 5.1f, 8.4f, 11.2f, 14.3f) // in Millions

    Column(modifier = Modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            val width = size.width
            val height = size.height
            val spacing = width / (dataPoints.size - 1)
            val maxVal = 16f
            val minVal = 2f

            val points = dataPoints.mapIndexed { index, value ->
                val x = index * spacing
                val y = height - ((value - minVal) / (maxVal - minVal) * (height - 30.dp.toPx())) - 10.dp.toPx()
                Offset(x, y)
            }

            // Draw gradient area beneath line
            val fillPath = Path().apply {
                moveTo(points.first().x, height)
                points.forEach { lineTo(it.x, it.y) }
                lineTo(points.last().x, height)
                close()
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF2563EB).copy(alpha = 0.25f), Color.Transparent)
                )
            )

            // Draw line
            val strokePath = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    lineTo(points[i].x, points[i].y)
                }
            }

            drawPath(
                path = strokePath,
                color = Color(0xFF2563EB),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // Draw dots
            points.forEach { pt ->
                drawCircle(
                    color = Color.White,
                    radius = 4.5.dp.toPx(),
                    center = pt
                )
                drawCircle(
                    color = Color(0xFF2563EB),
                    radius = 3.dp.toPx(),
                    center = pt
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Days of week row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            days.forEach { day ->
                Text(
                    text = day,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
