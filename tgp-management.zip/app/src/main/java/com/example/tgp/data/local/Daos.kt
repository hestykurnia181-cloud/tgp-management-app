package com.example.tgp.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.tgp.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE role = 'MASTER' LIMIT 1")
    suspend fun getMasterUser(): UserEntity?

    @Query("SELECT COUNT(*) FROM users WHERE role = 'MASTER'")
    suspend fun countMaster(): Int

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE role = 'OWNER' ORDER BY createdAt DESC")
    fun getAllOwners(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE role = 'ADMIN_OWNER' AND ownerId = :ownerId ORDER BY createdAt DESC")
    fun getAdminOwnersByOwner(ownerId: String): Flow<List<UserEntity>>

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Query("DELETE FROM users WHERE userId = :userId")
    suspend fun deleteUser(userId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminAssignment(assignment: AdminBusinessAssignmentEntity)

    @Query("SELECT businessId FROM admin_business_assignments WHERE userId = :userId")
    suspend fun getAssignedBusinessIds(userId: String): List<String>

    @Query("SELECT businessId FROM admin_business_assignments WHERE userId = :userId")
    fun getAssignedBusinessIdsFlow(userId: String): Flow<List<String>>

    @Query("DELETE FROM admin_business_assignments WHERE userId = :userId")
    suspend fun clearAdminAssignments(userId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaffBinding(binding: StaffBusinessBindingEntity)

    @Query("SELECT * FROM staff_business_bindings WHERE businessId = :businessId")
    fun getStaffBindingsForBusiness(businessId: String): Flow<List<StaffBusinessBindingEntity>>

    @Query("SELECT * FROM staff_business_bindings WHERE userId = :userId LIMIT 1")
    suspend fun getStaffBinding(userId: String): StaffBusinessBindingEntity?
}

@Dao
interface BusinessDao {
    @Query("SELECT * FROM businesses WHERE ownerId = :ownerId ORDER BY createdAt DESC")
    fun getBusinessesByOwner(ownerId: String): Flow<List<BusinessEntity>>

    @Query("SELECT * FROM businesses WHERE ownerId = :ownerId ORDER BY createdAt DESC")
    suspend fun getBusinessesByOwnerList(ownerId: String): List<BusinessEntity>

    @Query("SELECT * FROM businesses WHERE businessId = :businessId LIMIT 1")
    suspend fun getBusinessById(businessId: String): BusinessEntity?

    @Query("SELECT * FROM businesses WHERE businessId = :businessId LIMIT 1")
    fun getBusinessByIdFlow(businessId: String): Flow<BusinessEntity?>

    @Query("SELECT * FROM businesses WHERE businessId IN (:businessIds) ORDER BY name ASC")
    fun getBusinessesByIds(businessIds: List<String>): Flow<List<BusinessEntity>>

    @Query("SELECT * FROM businesses ORDER BY createdAt DESC")
    fun getAllBusinesses(): Flow<List<BusinessEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBusiness(business: BusinessEntity)

    @Update
    suspend fun updateBusiness(business: BusinessEntity)
}

@Dao
interface ItemDao {
    @Query("SELECT * FROM items WHERE businessId = :businessId ORDER BY name ASC")
    fun getItemsByBusiness(businessId: String): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items WHERE businessId IN (:businessIds) ORDER BY name ASC")
    fun getItemsForMultipleBusinesses(businessIds: List<String>): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items WHERE businessId = :businessId ORDER BY name ASC")
    suspend fun getItemsByBusinessList(businessId: String): List<ItemEntity>

    @Query("SELECT * FROM items WHERE itemId = :itemId LIMIT 1")
    suspend fun getItemById(itemId: String): ItemEntity?

    @Query("SELECT * FROM items WHERE businessId = :businessId AND (sku = :sku OR name = :name) LIMIT 1")
    suspend fun findMatchingItem(businessId: String, sku: String, name: String): ItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ItemEntity)

    @Update
    suspend fun updateItem(item: ItemEntity)

    @Query("UPDATE items SET stockQuantity = stockQuantity - :qty, updatedAt = :timestamp WHERE itemId = :itemId AND stockQuantity >= :qty")
    suspend fun deductStockSafely(itemId: String, qty: Double, timestamp: Long): Int

    @Query("UPDATE items SET stockQuantity = stockQuantity + :qty, updatedAt = :timestamp WHERE itemId = :itemId")
    suspend fun addStock(itemId: String, qty: Double, timestamp: Long): Int

    @Query("DELETE FROM items WHERE itemId = :itemId")
    suspend fun deleteItem(itemId: String)
}

@Dao
interface StockMutationDao {
    @Query("SELECT * FROM stock_mutations WHERE businessId = :businessId ORDER BY timestamp DESC")
    fun getMutationsByBusiness(businessId: String): Flow<List<StockMutationEntity>>

    @Query("SELECT * FROM stock_mutations ORDER BY timestamp DESC")
    fun getAllMutations(): Flow<List<StockMutationEntity>>

    @Insert
    suspend fun insertMutation(mutation: StockMutationEntity)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_transactions WHERE businessId = :businessId ORDER BY timestamp DESC")
    fun getLedgerByBusiness(businessId: String): Flow<List<LedgerTransactionEntity>>

    @Query("SELECT * FROM ledger_transactions WHERE businessId IN (:businessIds) ORDER BY timestamp DESC")
    fun getLedgerForMultipleBusinesses(businessIds: List<String>): Flow<List<LedgerTransactionEntity>>

    @Insert
    suspend fun insertLedger(tx: LedgerTransactionEntity)
}

@Dao
interface TransferDao {
    @Query("SELECT * FROM transfers WHERE ownerId = :ownerId ORDER BY createdAt DESC")
    fun getTransfersByOwner(ownerId: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE sourceBusinessId = :businessId OR destBusinessId = :businessId ORDER BY createdAt DESC")
    fun getTransfersByBusiness(businessId: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE ownerId = :ownerId AND status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingTransfersByOwner(ownerId: String): Flow<List<TransferEntity>>

    @Query("SELECT * FROM transfers WHERE transferId = :transferId LIMIT 1")
    suspend fun getTransferById(transferId: String): TransferEntity?

    @Insert
    suspend fun insertTransfer(transfer: TransferEntity)

    @Update
    suspend fun updateTransfer(transfer: TransferEntity)
}

@Dao
interface DamagedGoodsDao {
    @Query("SELECT * FROM damaged_goods_reports WHERE businessId = :businessId ORDER BY timestamp DESC")
    fun getReportsByBusiness(businessId: String): Flow<List<DamagedGoodsReportEntity>>

    @Query("SELECT d.* FROM damaged_goods_reports d INNER JOIN businesses b ON d.businessId = b.businessId WHERE b.ownerId = :ownerId AND d.status = 'PENDING' ORDER BY d.timestamp DESC")
    fun getPendingReportsByOwner(ownerId: String): Flow<List<DamagedGoodsReportEntity>>

    @Query("SELECT * FROM damaged_goods_reports WHERE reportId = :reportId LIMIT 1")
    suspend fun getReportById(reportId: String): DamagedGoodsReportEntity?

    @Insert
    suspend fun insertReport(report: DamagedGoodsReportEntity)

    @Update
    suspend fun updateReport(report: DamagedGoodsReportEntity)
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales_orders WHERE businessId = :businessId ORDER BY timestamp DESC")
    fun getSalesByBusiness(businessId: String): Flow<List<SaleOrderEntity>>

    @Query("SELECT * FROM sales_orders WHERE businessId IN (:businessIds) ORDER BY timestamp DESC")
    fun getSalesForMultipleBusinesses(businessIds: List<String>): Flow<List<SaleOrderEntity>>

    @Insert
    suspend fun insertSale(sale: SaleOrderEntity)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendances WHERE businessId = :businessId ORDER BY timestamp DESC")
    fun getAttendanceByBusiness(businessId: String): Flow<List<AttendanceEntity>>

    @Insert
    suspend fun insertAttendance(attendance: AttendanceEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 300")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE businessId = :businessId ORDER BY timestamp DESC LIMIT 200")
    fun getLogsByBusiness(businessId: String): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insertLog(log: AuditLogEntity)
}
