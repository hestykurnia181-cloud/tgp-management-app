package com.example.tgp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgp.data.model.BusinessModule
import com.example.tgp.data.model.UserRole
import com.example.tgp.ui.components.ModulePill
import com.example.tgp.ui.components.RoleBadge
import com.example.tgp.ui.components.StatCard
import com.example.tgp.ui.viewmodel.AppScreen
import com.example.tgp.ui.viewmodel.TgpViewModel

@Composable
fun BusinessHomeScreen(
    viewModel: TgpViewModel,
    onOpenSwitchBusiness: () -> Unit
) {
    val session by viewModel.currentSession.collectAsState()
    val activeBusiness by viewModel.activeBusiness.collectAsState()
    val businesses by viewModel.authorizedBusinesses.collectAsState()
    val items by viewModel.activeItems.collectAsState()
    val ledger by viewModel.activeLedger.collectAsState()

    var showAddStaffDialog by remember { mutableStateOf(false) }
    var selectedStaffRole by remember { mutableStateOf(UserRole.CASHIER) }

    // If NO business is selected, show an explicit selection banner (NO fallback to businesses[0])
    if (activeBusiness == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Belum Ada Business Dipilih",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Sesuai standar TGP Business Isolation, sistem tidak menggunakan fallback otomatis. Silakan pilih Business aktif yang ingin Anda kelola.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onOpenSwitchBusiness,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("btn_select_active_business")
            ) {
                Icon(Icons.Default.TouchApp, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Pilih Business Sekarang (${businesses.size} Tersedia)")
            }
        }
        return
    }

    val biz = activeBusiness!!
    val userRole = session?.user?.role ?: UserRole.STAFF
    val isCashier = userRole == UserRole.CASHIER

    // Calculate metrics for active business only
    val totalIncome = ledger.filter { it.type.name == "PEMASUKAN" }.sumOf { it.amount }
    val totalExpense = ledger.filter { it.type.name == "PENGELUARAN" }.sumOf { it.amount }
    val netBalance = totalIncome - totalExpense

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = biz.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Template: ${biz.templateType.displayName}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            onClick = onOpenSwitchBusiness,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(Icons.Default.Sync, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ganti", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Modul Aktif Bisnis Ini:", fontSize = 11.5.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        biz.getModuleList().forEach { mod ->
                            ModulePill(module = mod)
                        }
                    }
                }
            }
        }

        // Summary metrics - CASHIER CANNOT SEE SENSITIVE FINANCIAL METRICS
        if (!isCashier && biz.hasModule(BusinessModule.FINANCE)) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "Pemasukan",
                        value = "Rp ${totalIncome.toLong()}",
                        icon = Icons.Default.TrendingUp,
                        accentColor = Color(0xFF10B981),
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Saldo Kas",
                        value = "Rp ${netBalance.toLong()}",
                        icon = Icons.Default.AccountBalanceWallet,
                        accentColor = Color(0xFF2563EB),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Text(
                text = "Modul Operasional Bisnis",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Operational Modules - STRICTLY ONLY ACTIVE MODULES CAN BE ACCESSED!
        val activeModuleList = biz.getModuleList()
        items(activeModuleList) { module ->
            ModuleActionCard(
                module = module,
                isCashier = isCashier,
                onClick = {
                    when (module) {
                        BusinessModule.POS -> viewModel.navigateTo(AppScreen.POS_MODULE)
                        BusinessModule.INVENTORY -> viewModel.navigateTo(AppScreen.INVENTORY_MODULE)
                        BusinessModule.TRANSFER -> viewModel.navigateTo(AppScreen.TRANSFER_MODULE)
                        BusinessModule.DAMAGED_GOODS -> viewModel.navigateTo(AppScreen.DAMAGED_GOODS_MODULE)
                        BusinessModule.FINANCE -> {
                            if (!isCashier) viewModel.navigateTo(AppScreen.FINANCE_MODULE)
                        }
                        BusinessModule.ATTENDANCE -> viewModel.navigateTo(AppScreen.ATTENDANCE_MODULE)
                        BusinessModule.REPORTS -> viewModel.navigateTo(AppScreen.REPORTS_MODULE)
                    }
                }
            )
        }

        // Add Staff Section for OWNER and ADMIN OWNER
        if (userRole in listOf(UserRole.OWNER, UserRole.ADMIN_OWNER, UserRole.LEADER)) {
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Manajemen Karyawan Bisnis", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Kelola LEADER, STAFF, atau CASHIER terikat", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Button(
                                onClick = { showAddStaffDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_add_business_staff")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Tambah Staff", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddStaffDialog) {
        var username by remember { mutableStateOf("") }
        var fullName by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(UserRole.CASHIER) }

        AlertDialog(
            onDismissRequest = { showAddStaffDialog = false },
            title = {
                Text("Tambah Staff ke ${biz.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("Username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Nama Lengkap") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password (Min. 6 Karakter)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Pilih Role Staff:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    val allowedRoles = if (userRole == UserRole.LEADER) {
                        listOf(UserRole.STAFF, UserRole.CASHIER)
                    } else {
                        listOf(UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        allowedRoles.forEach { r ->
                            FilterChip(
                                selected = role == r,
                                onClick = { role = r },
                                label = { Text(r.name, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createStaff(biz.businessId, username, password, fullName, role)
                        showAddStaffDialog = false
                    },
                    enabled = username.isNotBlank() && fullName.isNotBlank() && password.length >= 6
                ) {
                    Text("Simpan Staff")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddStaffDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun ModuleActionCard(
    module: BusinessModule,
    isCashier: Boolean,
    onClick: () -> Unit
) {
    val isRestrictedForCashier = isCashier && module == BusinessModule.FINANCE
    val (icon, color) = when (module) {
        BusinessModule.POS -> Pair(Icons.Default.PointOfSale, Color(0xFF2563EB))
        BusinessModule.INVENTORY -> Pair(Icons.Default.Inventory2, Color(0xFF0D9488))
        BusinessModule.TRANSFER -> Pair(Icons.Default.SwapHoriz, Color(0xFF7C3AED))
        BusinessModule.DAMAGED_GOODS -> Pair(Icons.Default.ReportProblem, Color(0xFFDC2626))
        BusinessModule.FINANCE -> Pair(Icons.Default.AccountBalance, Color(0xFF16A34A))
        BusinessModule.ATTENDANCE -> Pair(Icons.Default.Badge, Color(0xFFEA580C))
        BusinessModule.REPORTS -> Pair(Icons.Default.Assessment, Color(0xFF4F46E5))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isRestrictedForCashier) { onClick() }
            .testTag("card_module_${module.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(color.copy(alpha = 0.16f), color.copy(alpha = 0.06f))
                        )
                    )
                    .border(1.dp, color.copy(alpha = 0.22f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = module.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isRestrictedForCashier) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isRestrictedForCashier) "Terkunci: Role CASHIER tidak memiliki izin akses keuangan." else module.description,
                    fontSize = 11.5.sp,
                    lineHeight = 15.sp,
                    color = if (isRestrictedForCashier) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = if (isRestrictedForCashier) Icons.Default.Lock else Icons.Default.ChevronRight,
                contentDescription = null,
                tint = if (isRestrictedForCashier) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}
