package com.example.tgp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgp.data.model.UserRole
import com.example.tgp.ui.components.StatusBadge
import com.example.tgp.ui.viewmodel.TgpViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TransferScreen(viewModel: TgpViewModel) {
    val transfers by viewModel.activeTransfers.collectAsState()
    val businesses by viewModel.authorizedBusinesses.collectAsState()
    val activeBiz by viewModel.activeBusiness.collectAsState()
    val items by viewModel.activeItems.collectAsState()
    val session by viewModel.currentSession.collectAsState()

    var showCreateTransferDialog by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("SEMUA") }

    val filteredTransfers = remember(transfers, selectedFilter) {
        when (selectedFilter) {
            "PENDING" -> transfers.filter { it.status.name == "PENDING" }
            "APPROVED" -> transfers.filter { it.status.name == "APPROVED" }
            "REJECTED" -> transfers.filter { it.status.name == "REJECTED" }
            else -> transfers
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Transfer Antar Business",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hanya diizinkan antar bisnis dengan OWNER yang sama",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (activeBiz != null && businesses.size > 1) {
                    Button(
                        onClick = { showCreateTransferDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_create_transfer")
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Buat Transfer", fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("SEMUA", "PENDING", "APPROVED", "REJECTED").forEach { f ->
                    FilterChip(
                        selected = selectedFilter == f,
                        onClick = { selectedFilter = f },
                        label = { Text(f, fontSize = 11.sp) }
                    )
                }
            }
        }

        if (filteredTransfers.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Belum ada riwayat transfer barang.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            items(filteredTransfers) { t ->
                val srcBiz = businesses.find { it.businessId == t.sourceBusinessId }
                val dstBiz = businesses.find { it.businessId == t.destBusinessId }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = t.transferReference,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            StatusBadge(status = t.status.name)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = srcBiz?.name ?: "Bisnis Asal",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = dstBiz?.name ?: "Bisnis Tujuan",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Item: ${t.itemName} • Jumlah: ${t.quantity.toInt()} unit",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (t.notes.isNotBlank()) {
                            Text(
                                text = "Catatan: ${t.notes}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Dibuat: ${SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(t.createdAt))}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (t.status.name != "PENDING" && t.approvedBy != null) {
                                Text(
                                    text = "Oleh: ${t.approvedBy}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (t.status.name == "APPROVED") Color(0xFF15803D) else Color(0xFFB91C1C)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateTransferDialog && activeBiz != null) {
        CreateTransferDialog(
            businesses = businesses,
            sourceBusinessId = activeBiz!!.businessId,
            items = items,
            onDismiss = { showCreateTransferDialog = false },
            onConfirm = { sourceId, destId, itemId, qty, notes ->
                viewModel.requestTransfer(sourceId, destId, itemId, qty, notes)
                showCreateTransferDialog = false
            }
        )
    }
}
