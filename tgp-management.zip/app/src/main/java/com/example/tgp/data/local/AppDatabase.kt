package com.example.tgp.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.tgp.data.model.*

class TgpTypeConverters {
    @TypeConverter
    fun fromUserRole(role: UserRole): String = role.name

    @TypeConverter
    fun toUserRole(value: String): UserRole = runCatching { UserRole.valueOf(value) }.getOrDefault(UserRole.STAFF)

    @TypeConverter
    fun fromBusinessTemplate(template: BusinessTemplate): String = template.name

    @TypeConverter
    fun toBusinessTemplate(value: String): BusinessTemplate = runCatching { BusinessTemplate.valueOf(value) }.getOrDefault(BusinessTemplate.RETAIL)

    @TypeConverter
    fun fromTransferStatus(status: TransferStatus): String = status.name

    @TypeConverter
    fun toTransferStatus(value: String): TransferStatus = runCatching { TransferStatus.valueOf(value) }.getOrDefault(TransferStatus.PENDING)

    @TypeConverter
    fun fromDamagedStatus(status: DamagedStatus): String = status.name

    @TypeConverter
    fun toDamagedStatus(value: String): DamagedStatus = runCatching { DamagedStatus.valueOf(value) }.getOrDefault(DamagedStatus.PENDING)

    @TypeConverter
    fun fromPaymentMethod(method: PaymentMethod): String = method.name

    @TypeConverter
    fun toPaymentMethod(value: String): PaymentMethod = runCatching { PaymentMethod.valueOf(value) }.getOrDefault(PaymentMethod.CASH)

    @TypeConverter
    fun fromLedgerType(type: LedgerType): String = type.name

    @TypeConverter
    fun toLedgerType(value: String): LedgerType = runCatching { LedgerType.valueOf(value) }.getOrDefault(LedgerType.PEMASUKAN)

    @TypeConverter
    fun fromMutationType(type: MutationType): String = type.name

    @TypeConverter
    fun toMutationType(value: String): MutationType = runCatching { MutationType.valueOf(value) }.getOrDefault(MutationType.INITIAL)
}

@Database(
    entities = [
        UserEntity::class,
        BusinessEntity::class,
        AdminBusinessAssignmentEntity::class,
        StaffBusinessBindingEntity::class,
        ItemEntity::class,
        StockMutationEntity::class,
        LedgerTransactionEntity::class,
        TransferEntity::class,
        DamagedGoodsReportEntity::class,
        SaleOrderEntity::class,
        AttendanceEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(TgpTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun businessDao(): BusinessDao
    abstract fun itemDao(): ItemDao
    abstract fun stockMutationDao(): StockMutationDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun transferDao(): TransferDao
    abstract fun damagedGoodsDao(): DamagedGoodsDao
    abstract fun saleDao(): SaleDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tgp_management_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
