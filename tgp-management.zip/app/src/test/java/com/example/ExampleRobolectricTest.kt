package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.tgp.data.local.AppDatabase
import com.example.tgp.data.local.SecurityHelper
import com.example.tgp.data.model.*
import com.example.tgp.data.repository.TgpRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repo: TgpRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = TgpRepository(db)
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun appNameStringResourceIsTgpManagement() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("TGP Management", appName)
    }

    @Test
    fun securityPasswordHashingVerification() {
        val salt = SecurityHelper.generateSalt()
        val hash = SecurityHelper.hashPassword("SuperSecret123", salt)
        assertTrue(SecurityHelper.verifyPassword("SuperSecret123", salt, hash))
        assertFalse(SecurityHelper.verifyPassword("WrongPassword", salt, hash))
    }

    @Test
    fun testMasterSetupAndBusinessCreationAndTransfer() = runBlocking {
        // 1. Setup MASTER
        val masterRes = repo.setupInitialMaster("master_admin", "password123", "Canonical Master")
        assertTrue(masterRes.isSuccess)
        val master = masterRes.getOrThrow()
        assertEquals(UserRole.MASTER, master.role)

        // 2. MASTER creates OWNER
        val ownerRes = repo.createOwner(master, "owner_budi", "password123", "Budi Santoso")
        assertTrue(ownerRes.isSuccess)
        val owner = ownerRes.getOrThrow()
        assertEquals(UserRole.OWNER, owner.role)

        // 3. OWNER creates 2 Businesses (Max 2 modules each)
        val biz1Res = repo.createBusiness(
            owner,
            "Toko Retail Jakarta",
            BusinessTemplate.RETAIL,
            listOf(BusinessModule.POS, BusinessModule.INVENTORY)
        )
        assertTrue(biz1Res.isSuccess)
        val biz1 = biz1Res.getOrThrow()

        val biz2Res = repo.createBusiness(
            owner,
            "Toko Retail Bandung",
            BusinessTemplate.RETAIL,
            listOf(BusinessModule.INVENTORY, BusinessModule.TRANSFER)
        )
        assertTrue(biz2Res.isSuccess)
        val biz2 = biz2Res.getOrThrow()

        // 4. Add stock item to Biz 1
        val item1 = ItemEntity(
            businessId = biz1.businessId,
            name = "Kemeja Putih",
            sku = "KMJ-001",
            category = "Pakaian",
            type = "PRODUCT",
            costPrice = 50000.0,
            sellingPrice = 85000.0,
            stockQuantity = 20.0
        )
        repo.createOrUpdateItem(owner, item1)

        // 5. Create transfer request from Biz 1 to Biz 2 (Same OWNER)
        val transferRes = repo.createTransferRequest(
            owner,
            biz1.businessId,
            biz2.businessId,
            item1.itemId,
            5.0,
            "Restock cabang Bandung"
        )
        assertTrue(transferRes.isSuccess)
        val transfer = transferRes.getOrThrow()
        assertEquals(TransferStatus.PENDING, transfer.status)

        // 6. Approve transfer atomically
        val approveRes = repo.approveTransfer(owner, transfer.transferId)
        assertTrue(approveRes.isSuccess)

        // 7. Verify atomic results:
        // - Stock in Biz 1 must be 15
        val updatedItem1 = db.itemDao().getItemById(item1.itemId)
        assertNotNull(updatedItem1)
        assertEquals(15.0, updatedItem1!!.stockQuantity, 0.001)

        // - Stock in Biz 2 must be 5
        val destItems = db.itemDao().getItemsByBusinessList(biz2.businessId)
        assertEquals(1, destItems.size)
        assertEquals("Kemeja Putih", destItems[0].name)
        assertEquals(5.0, destItems[0].stockQuantity, 0.001)
    }

    @Test
    fun testOwnerDashboardBusinessesIsolation() = runBlocking<Unit> {
        // Test quick login for OWNER
        val sessionRes = repo.quickLoginDemoOwner()
        assertTrue(sessionRes.isSuccess)
        val session = sessionRes.getOrThrow()
        assertEquals(UserRole.OWNER, session.user.role)

        // Verify that Business A, Business B, and Business C exist
        val businesses = db.businessDao().getBusinessesByOwnerList(session.user.userId)
        assertEquals(3, businesses.size)

        val bizA = businesses.find { it.name == "Business A" }!!
        val bizB = businesses.find { it.name == "Business B" }!!
        val bizC = businesses.find { it.name == "Business C" }!!

        // Verify data isolation: each business has distinct stock and ledger entries
        val itemsA = db.itemDao().getItemsByBusinessList(bizA.businessId)
        val itemsB = db.itemDao().getItemsByBusinessList(bizB.businessId)
        val itemsC = db.itemDao().getItemsByBusinessList(bizC.businessId)

        assertTrue(itemsA.isNotEmpty())
        assertTrue(itemsB.isNotEmpty())
        assertTrue(itemsC.isNotEmpty())
        assertTrue(itemsA.none { it.businessId == bizB.businessId || it.businessId == bizC.businessId })

        // Verify isolated ledger entries
        val ledgerA = db.ledgerDao().getLedgerByBusiness(bizA.businessId).first()
        val ledgerB = db.ledgerDao().getLedgerByBusiness(bizB.businessId).first()
        val ledgerC = db.ledgerDao().getLedgerByBusiness(bizC.businessId).first()

        assertTrue(ledgerA.isNotEmpty())
        assertTrue(ledgerB.isNotEmpty())
        assertTrue(ledgerC.isNotEmpty())

        // Verify aggregated retrieval
        val allLedger = db.ledgerDao().getLedgerForMultipleBusinesses(listOf(bizA.businessId, bizB.businessId, bizC.businessId)).first()
        assertEquals(ledgerA.size + ledgerB.size + ledgerC.size, allLedger.size)
    }
}
