package com.example

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import com.example.tgp.data.model.UserRole
import com.example.tgp.ui.components.RoleBadge
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun roleBadgeRendersSuccessfully() {
        composeTestRule.setContent {
            MyApplicationTheme {
                Box(modifier = Modifier.padding(16.dp)) {
                    RoleBadge(role = UserRole.OWNER)
                }
            }
        }
    }
}
